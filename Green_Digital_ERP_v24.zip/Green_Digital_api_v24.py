import re
"""
rio_erp_api.py — GREEN DIGITALS ERP v2.0
FastAPI backend replacing the PowerShell script.
Data stored in MongoDB Atlas.

Run locally:
    uvicorn rio_erp_api:app --host 0.0.0.0 --port 8001 --reload

Deploy on Render.com:
    Start command: uvicorn rio_erp_api:app --host 0.0.0.0 --port 8001
"""

import os, re, bcrypt, sys, secrets
from contextlib import asynccontextmanager
from datetime import datetime, date
from typing import Optional, Any

from fastapi import FastAPI, Request, Query
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel
from fastapi.responses import JSONResponse, HTMLResponse, FileResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.collection import Collection
from bson import ObjectId
from dotenv import load_dotenv

# Use logging so uvicorn captures and displays output properly
import logging
import logging.handlers
import pathlib

# ── Logging setup ────────────────────────────────────────────────
# Windows (local run): writes to C:\Rio\Logs\rio_app.log
# Render / Linux:      stdout only (visible in Render → Logs tab)
import platform as _platform

_fmt = logging.Formatter("%(asctime)s | %(levelname)-5s | %(message)s",
                          datefmt="%Y-%m-%d %H:%M:%S")

# Set up "rio_erp_api" logger cleanly — don't use basicConfig (conflicts with uvicorn)
logger = logging.getLogger("rio_erp_api")
logger.setLevel(logging.DEBUG)
logger.propagate = False   # prevent double-logging via root logger

# Always add stdout handler
_sh = logging.StreamHandler()
_sh.setFormatter(_fmt)
if not logger.handlers:    # avoid adding duplicate handlers on reload
    logger.addHandler(_sh)

# File handler — try C:\Rio\Logs on Windows, fallback to script directory
_LOG_FILE = None
_log_candidates = []
if _platform.system() == "Windows":
    _log_candidates = [
        pathlib.Path(r"C:\Rio\Logs"),
        pathlib.Path(os.path.dirname(os.path.abspath(__file__))) / "logs",
        pathlib.Path.cwd() / "logs",
    ]
else:
    # On Linux/Render: no file needed (use Render Logs tab)
    _log_candidates = []

for _log_candidate_dir in _log_candidates:
    try:
        _log_candidate_dir.mkdir(parents=True, exist_ok=True)
        _test = _log_candidate_dir / ".write_test"
        _test.touch(); _test.unlink()
        _LOG_FILE = _log_candidate_dir / "rio_app.log"
        _fh = logging.handlers.RotatingFileHandler(
            _LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=2, encoding="utf-8"
        )
        _fh.setFormatter(_fmt)
        logger.addHandler(_fh)
        logger.info("=== RIO — Log file: %s ===", _LOG_FILE)
        break
    except Exception as _log_ex:
        logger.debug("Log dir %s not writable: %s", _log_candidate_dir, _log_ex)

if not _LOG_FILE:
    if _platform.system() == "Windows":
        logger.warning("Could not create log file — check C:\\Rio\\Logs permissions")
    else:
        logger.info("=== GREEN DIGITALS ERP v2.0 — Render — check Logs tab ===")

load_dotenv(override=False)  # Never override Render environment variables

# ─────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────
MONGO_URI  = os.environ.get("MONGO_URI", "mongodb+srv://rioprintmediaa_db_Mani:Nannavinam%401212@rioprintmedia.6e7l1ak.mongodb.net/?appName=RIOPRINTMEDIA")
MONGO_DB   = os.environ.get("MONGO_DB",  "RioPrintMedia")
if MONGO_DB == "RioPrintMedia":
    print("WARNING: Green Digital is using the database name 'RioPrintMedia' (the MONGO_DB environment variable is not set). "
          "If Rio Print Media shares this cluster, both apps are using the SAME database. Set MONGO_DB on Render.")
# Rainbow's database name is now configurable (was hardcoded as "RainbowUmbrellas"
# further down in the file), so a test deployment can isolate Rainbow's data too
# via MONGO_DB_RAINBOW, the same way MONGO_DB isolates Rio's. Defaults to the
# existing production database name if unset, so production is unaffected.
MONGO_DB_RAINBOW = os.environ.get("MONGO_DB_RAINBOW", "RainbowUmbrellas")
HTML_FILE  = os.environ.get("HTML_FILE", "Green_Digital_ERP.html")

# ── Startup diagnostics ──
logger.info("=" * 60)
logger.info("GREEN DIGITALS ERP v2.0 — STARTING UP")
logger.info(f"MONGO_DB  = {MONGO_DB}")
logger.info(f"MONGO_DB_RAINBOW = {MONGO_DB_RAINBOW}")
if MONGO_URI:
    _safe = re.sub(r':(.*?)@', ':***@', MONGO_URI)
    logger.info(f"MONGO_URI = SET → {_safe[:70]}")
else:
    logger.error("MONGO_URI = NOT SET — add it in Render Environment Variables!")
logger.info("=" * 60)

# ─────────────────────────────────────────────
#  DB
# ─────────────────────────────────────────────
_client: MongoClient = None
_db = None

def _ensure_db_blocking() -> bool:
    """Connect to MongoDB if not already connected. Returns True if connected."""
    global _client, _db
    if _db is not None:
        try:
            _client.admin.command("ping")
            return True
        except Exception:
            _client = None
            _db = None
    if not MONGO_URI:
        logger.error("MONGO_URI not set — cannot connect to MongoDB")
        return False
    try:
        _client = MongoClient(
            MONGO_URI,
            serverSelectionTimeoutMS=8000,
            connectTimeoutMS=8000,
            socketTimeoutMS=15000,
        )
        _client.admin.command("ping")
        _db = _client[MONGO_DB]
        logger.info("MongoClient created, pinging Atlas...")
        # Create indexes
        try:
            _db["sales_records"].create_index([("SNo", DESCENDING)])
            _db["daily_expenses"].create_index([("ExpDate", DESCENDING)])
            _db["sales_invoices"].create_index([("InvoiceDate", DESCENDING)])
            _db["quotations"].create_index([("QuotationDate", DESCENDING)])
            logger.info("Indexes created")
        except Exception:
            pass
        ensure_default_users()
        return True
    except Exception as e:
        logger.error(f"MongoDB connection failed: {e}")
        _client = None
        _db = None
        return False

async def ensure_db() -> bool:
    """
    Async-safe wrapper around the blocking MongoDB connection check.
    Runs the actual pymongo calls in a worker thread so a slow/unresponsive
    Atlas connection never freezes the asyncio event loop (which would make
    the ENTIRE server unresponsive to all users, not just this request).
    """
    return await run_in_threadpool(_ensure_db_blocking)

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode(), hashed.encode())
    except Exception:
        return False

def ensure_default_users():
    """Always ensure admin user exists."""
    try:
        existing = col("green_digital_users").find_one({"username": "admin"})
        if not existing:
            col("green_digital_users").insert_one({
                "username": "admin",
                "password": hash_password("rio@admin"),
                "role": "admin",
                "name": "Administrator",
                "scope": "all"
            })
            logger.info("Admin user created: username=admin password=rio@admin")
        else:
            update_fields = {}
            if existing.get("role") != "admin":
                update_fields["role"] = "admin"
            if "scope" not in existing:
                update_fields["scope"] = "all"
            if update_fields:
                col("green_digital_users").update_one({"username": "admin"}, {"$set": update_fields})
    except Exception as e:
        logger.error(f"ensure_default_users error: {e}")


def get_db():
    return _db

from contextvars import ContextVar
COMPANY_DBS = {"rio": MONGO_DB, "rainbow": MONGO_DB_RAINBOW}
_company_ctx: ContextVar[str] = ContextVar("company", default="rio")

def col(name: str) -> Collection:
    company = _company_ctx.get()
    if _client and company == "rainbow":
        return _client[MONGO_DB_RAINBOW][name]
    return _db[name]

def shared_col(name: str) -> Collection:
    """Always uses RioPrintMedia — for shared data like customers."""
    return _db[name]

# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────
def clean(doc: dict) -> dict:
    """Remove MongoDB _id and convert ObjectId."""
    if doc is None:
        return None
    doc.pop("_id", None)
    return doc

def clean_list(docs) -> list:
    return [clean(d) for d in docs]

def to_float(v, default=None):
    if v is None or v == "":
        return default
    try:
        return float(v)
    except:
        return default

def to_int(v, default=None):
    if v is None or v == "":
        return default
    try:
        return int(v)
    except:
        return default

def fy_from_date(d: str) -> str:
    """Return FY string like '2024-25' from a date string."""
    try:
        dt = datetime.strptime(d[:10], "%Y-%m-%d")
        m, y = dt.month, dt.year
        if m >= 4:
            return f"{y}-{str(y+1)[-2:]}"
        else:
            return f"{y-1}-{str(y)[-2:]}"
    except:
        return ""

def current_fy() -> str:
    return fy_from_date(datetime.now().strftime("%Y-%m-%d"))

def fy_range(fy: str):
    """Return (from_date, to_date) strings for a FY like '2024-25'."""
    try:
        y = int(fy.split("-")[0])
        return f"{y}-04-01", f"{y+1}-03-31"
    except:
        return None, None

def next_invoice_no(inv_type: str, fy: str) -> str:
    """Next number in this financial year's series: GST -> GD01, GD02 ...; Non-GST -> GDN01, GDN02 ...
    Cancelled invoices keep their number and still count here, so a number is never reused after a cancellation."""
    fy_from, fy_to = fy_range(fy)
    pfx = "GD" if inv_type == "GST" else "GDN"
    pipeline = [
        {"$match": {
            "InvoiceNo": {"$regex": r"^%s\d" % pfx},
            "$or": [{"FY": fy}, {"$and": [{"FY": None}, {"InvoiceDate": {"$gte": fy_from, "$lte": fy_to}}]}]
        }},
        {"$project": {"num": {"$toInt": {"$substr": ["$InvoiceNo", len(pfx), 10]}}}},
        {"$group": {"_id": None, "max": {"$max": "$num"}}}
    ]
    res = list(col("sales_invoices").aggregate(pipeline))
    n = (res[0]["max"] if res else 0) + 1
    return f"{pfx}{n:02d}"

def next_quotation_no(q_type: str, fy: str) -> str:
    fy_from, fy_to = fy_range(fy)
    if q_type == "GST":
        pipeline = [
            {"$match": {"QuotationNo": {"$regex": r"^Q\d"}, "QuotationDate": {"$gte": fy_from, "$lte": fy_to}}},
            {"$project": {"num": {"$toInt": {"$substr": ["$QuotationNo", 1, 10]}}}},
            {"$group": {"_id": None, "max": {"$max": "$num"}}}
        ]
        res = list(col("quotations").aggregate(pipeline))
        n = (res[0]["max"] if res else 0) + 1
        return f"Q{n:02d}"
    else:
        pipeline = [
            {"$match": {"QuotationNo": {"$regex": r"^QN"}, "QuotationDate": {"$gte": fy_from, "$lte": fy_to}}},
            {"$project": {"num": {"$toInt": {"$substr": ["$QuotationNo", 2, 10]}}}},
            {"$group": {"_id": None, "max": {"$max": "$num"}}}
        ]
        res = list(col("quotations").aggregate(pipeline))
        n = (res[0]["max"] if res else 0) + 1
        return f"QN{n:02d}"

def next_product_code() -> str:
    pipeline = [
        {"$match": {"Code": {"$regex": r"^P"}}},
        {"$project": {"num": {"$toInt": {"$substr": ["$Code", 1, 10]}}}},
        {"$group": {"_id": None, "max": {"$max": "$num"}}}
    ]
    res = list(col("products").aggregate(pipeline))
    n = (res[0]["max"] if res else 0) + 1
    return f"P{n:03d}"

def next_id(collection_name: str, field: str = "Id") -> int:
    """Atomic ID generation using a counters collection."""
    result = _db["_counters"].find_one_and_update(
        {"_id": collection_name},
        {"$inc": {"seq": 1}},
        upsert=True,
        return_document=True
    )
    return result["seq"]

async def require_db():
    """Call at the start of every endpoint to ensure DB is ready."""
    if not await ensure_db():
        raise Exception("Database not connected")

def init_indexes():
    """Create indexes for fast queries."""
    try:
        _db["sales_records"].create_index([("SNo", DESCENDING)])
        _db["daily_expenses"].create_index([("ExpDate", DESCENDING)])
        _db["sales_invoices"].create_index([("InvoiceDate", DESCENDING)])
        _db["quotations"].create_index([("QuotationDate", DESCENDING)])
        logger.info("Indexes created")
    except Exception as e:
        logger.warning(f"Index creation (non-fatal): {e}")

def init_counters():
    """Seed counters from current max IDs in each collection."""
    collections = [
        ("sales_records", "SNo"), ("daily_expenses", "Id"),
        ("notes", "Id"), ("followups", "Id"), ("green_digital_clients", "Id"),
        ("expense_categories", "Id"), ("jobs", "Id"), ("account_balances", "Id"),
        ("account_ledger", "Id"), ("products", "Id"), ("sales_invoices", "Id"),
        ("quotations", "Id"),
    ]
    for coll_name, field in collections:
        existing = _db["_counters"].find_one({"_id": coll_name})
        if not existing:
            pipeline = [{"$group": {"_id": None, "max": {"$max": f"${field}"}}}]
            res = list(_db[coll_name].aggregate(pipeline))
            max_val = to_int(res[0]["max"]) if res and res[0].get("max") is not None else 0
            _db["_counters"].update_one(
                {"_id": coll_name},
                {"$setOnInsert": {"seq": max_val}},
                upsert=True
            )

def set_sales_ledger_credits(sno: int, customer: str, job_name: str, payments: list):
    """Delete old ledger entries for a sales record and recreate them.
    After recreating, recalculate running balances for all affected accounts."""
    col("account_ledger").delete_many({"SalesRef": sno})
    affected = set()  # track which (account, fy) pairs need rebalancing
    for pay in payments:
        amt  = to_float(pay.get("Amt"))
        dt   = (pay.get("Date") or "").strip()
        mode = (pay.get("Mode") or "").strip()
        if not amt or amt <= 0 or not dt:
            continue
        acct = ledger_account_for(mode)
        if not acct:
            continue
        fy = fy_from_date(dt)
        if not fy:
            continue
        jn_str = f" — {job_name}" if job_name else ""
        desc = f"Sales: {customer}{jn_str}"
        col("account_ledger").insert_one({
            "Id": next_id("account_ledger"), "AccountName": acct, "EntryDate": dt,
            "Description": desc, "CreditAmt": amt, "DebitAmt": 0,
            "Balance": 0, "EntryType": "Credit", "FY": fy,
            "ExpenseRef": None, "SalesRef": sno
        })
        affected.add((acct, fy))
    # Recalculate running balances for all affected accounts
    for acct, fy in affected:
        recalc_ledger_balances(acct, fy)

def recalc_ledger_balances(account_name: str, fy: str):
    """
    Recalculate running balances for all entries of an account in a given FY,
    sorted by EntryDate then Id. Called after any edit or delete of a ledger entry
    to ensure the Balance column stays accurate throughout.
    """
    entries = list(col("account_ledger").find(
        {"AccountName": account_name, "FY": fy},
        sort=[("EntryDate", ASCENDING), ("Id", ASCENDING)]
    ))
    if not entries:
        return
    running = 0.0
    for entry in entries:
        running += to_float(entry.get("CreditAmt", 0))
        running -= to_float(entry.get("DebitAmt", 0))
        col("account_ledger").update_one(
            {"_id": entry["_id"]},
            {"$set": {"Balance": round(running, 2)}}
        )

# ─────────────────────────────────────────────
#  APP STARTUP
# ─────────────────────────────────────────────
_db_connected = False  # track real connection state

def _connect_mongo():
    """Attempt MongoDB connection. Returns True on success, False on failure."""
    global _client, _db, _db_connected
    if not MONGO_URI:
        logger.error("=" * 60)
        logger.error("MONGO_URI IS NOT SET!")
        logger.error("Go to Render → your service → Environment → Add:")
        logger.error("  MONGO_URI = mongodb+srv://user:pass@cluster...")
        logger.error("  MONGO_DB  = RioPrintMedia")
        logger.error("Then click Save and Manual Deploy")
        logger.error("=" * 60)
        _db_connected = False
        return False
    # Mask password for safe logging
    safe_uri = re.sub(r':(.*?)@', ':***@', MONGO_URI) if MONGO_URI else MONGO_URI
    logger.info(f"Connecting to MongoDB Atlas...")
    logger.info(f"URI: {safe_uri}")
    logger.info(f"DB:  {MONGO_DB}")
    try:
        _client = MongoClient(
            MONGO_URI,
            serverSelectionTimeoutMS=25000,
            connectTimeoutMS=25000,
            socketTimeoutMS=30000,
            tls=True,
            retryWrites=True,
        )
        logger.info("MongoClient created, pinging Atlas...")
        _client.admin.command("ping")
        _db = _client[MONGO_DB]
        _db_connected = True
        logger.info(f"✓ MongoDB Atlas connected: {MONGO_DB}")
        return True
    except Exception as e:
        _db_connected = False
        err_str = str(e)
        logger.error(f"✗ MongoDB connection FAILED: {err_str}")
        if "Authentication failed" in err_str or "auth" in err_str.lower():
            logger.error("→ CHECK: Username and password in MONGO_URI")
            logger.error("→ Special chars in password must be URL-encoded (@ = %40)")
        elif "network" in err_str.lower() or "timeout" in err_str.lower() or "timed out" in err_str.lower():
            logger.error("→ CHECK: MongoDB Atlas Network Access")
            logger.error("→ Go to Atlas → Network Access → Add IP: 0.0.0.0/0 (Allow All)")
            logger.error("→ Render uses dynamic IPs, so 0.0.0.0/0 is required")
        elif "SSL" in err_str or "TLS" in err_str:
            logger.error("→ SSL/TLS error — check Atlas cluster TLS settings")
        logger.error(f"→ URI used (masked): {safe_uri[:60]}...")
        return False

@asynccontextmanager
async def lifespan(app: FastAPI):
    # DO NOT raise — keep server alive even if DB is temporarily down.
    # Render cold starts can be slow; server retries on first real request.
    connected = _connect_mongo()
    if connected:
        try:
            init_indexes()
            logger.info("Indexes ready")
        except Exception as e:
            logger.warning(f"init_indexes error (non-fatal): {e}")
        try:
            init_counters()
            logger.info("Counters initialised")
        except Exception as e:
            logger.warning(f"init_counters error (non-fatal): {e}")
        try:
            ensure_default_users()
            logger.info("Users ready")
        except Exception as e:
            logger.warning(f"ensure_default_users error (non-fatal): {e}")
    else:
        logger.warning("Server started WITHOUT DB — will retry on first request")
    yield
    if _client:
        _client.close()
        logger.info("MongoDB connection closed")

app = FastAPI(title="GREEN DIGITALS ERP v3.0", lifespan=lifespan)

# ── Build/version marker ─────────────────────────────────────────
# Bump this string every time this file is packaged, so it's possible
# to confirm from the browser console (fetch('/api/version')) exactly
# which build is actually running on the live server — instead of
# guessing from behavior when something looks stale or cached.
BUILD_VERSION = "v95-2026-07-03"

@app.get("/api/version")
async def get_version():
    # api_level / api_build let the page check it is talking to a server new enough for it (see rioCheckServerLevel)
    return {"build": BUILD_VERSION, "mobile_toggle_route": True, "api_level": API_LEVEL, "api_build": API_BUILD}

@app.put("/api/quotations/{qid}")
async def update_quotation(qid: str, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    try:
        data = await request.json()
        data.pop("_id", None)
        items = data.get("Items", [])
        for item in items:
            item["TaxableValue"] = to_float(item.get("TaxableValue"))
            item["GSTRate"]      = to_float(item.get("GSTRate"))
            item["Total"]        = to_float(item.get("Total"))
        from bson import ObjectId
        col("quotations").update_one(
            {"_id": ObjectId(qid)},
            {"$set": data}
        )
        return {"success": True, "quotationNo": data.get("QuotationNo", "")}
    except Exception as e:
        return err(str(e), 500)


@app.middleware("http")
async def set_company_context(request, call_next):
    company = request.query_params.get("company", "rio")
    token = _company_ctx.set("rainbow" if company == "rainbow" else "rio")
    try:
        response = await call_next(request)
    finally:
        _company_ctx.reset(token)
    return response

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def ok(data=None, **kwargs):
    if data is not None:
        return JSONResponse(content=data)
    return JSONResponse(content={"ok": True, **kwargs})

def err(msg, status=400):
    return JSONResponse(content={"error": msg}, status_code=status)

# ─────────────────────────────────────────────
#  LIVE HTML PATCHER — applied every request
# ─────────────────────────────────────────────
# ─────────────────────────────────────────────
#  SERVE HTML DASHBOARD
# ─────────────────────────────────────────────
# ── In-memory HTML cache ────────────────────────────────────────
# The main dashboard HTML is several MB. Re-reading it from disk on
# every single page load means every concurrent request holds its own
# full copy in memory at once — on Render's free 512MB tier, a handful
# of simultaneous loads can be enough to trigger an OOM kill (which
# shows up to users as every endpoint suddenly returning 502). Loading
# it once at startup and reusing the same string avoids that entirely,
# and is also faster since there's no disk I/O per request.
_HTML_CACHE = {}

def _load_html_cached(file_path):
    if file_path in _HTML_CACHE:
        return _HTML_CACHE[file_path]
    if not os.path.exists(file_path):
        return None
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
    _HTML_CACHE[file_path] = content
    logger.info(f"Cached {file_path} in memory ({len(content)} bytes)")
    return content


@app.get("/", response_class=HTMLResponse)
async def serve_dashboard(request: Request):
    html = _load_html_cached(HTML_FILE)
    if html is None:
        logger.error(f"HTML file not found: {HTML_FILE} — cwd={os.getcwd()}")
        return HTMLResponse(f"<h2>File not found: {HTML_FILE}</h2><p>CWD: {os.getcwd()}</p><p>Files: {os.listdir('.')[:20]}</p>", 404)
    return HTMLResponse(html)

@app.get("/ledger", response_class=HTMLResponse)
async def serve_ledger(request: Request):
    """Standalone ledger diagnostic page"""
    LEDGER_FILE = "Green_Digital_ERP_ledger.html"
    if not os.path.exists(LEDGER_FILE):
        return HTMLResponse(f"<h2>Ledger file not found: {LEDGER_FILE}</h2>", 404)
    with open(LEDGER_FILE, "r", encoding="utf-8") as f:
        html = f.read()
    return HTMLResponse(html)

# ─────────────────────────────────────────────
#  MOBILE APP
# ─────────────────────────────────────────────


@app.post("/api/log")
async def client_log(request: Request):
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(content={"ok": False}, status_code=400)
    level   = str(body.get("level",  "INFO")).upper()
    user    = str(body.get("user",   "unknown"))
    action  = str(body.get("action", ""))
    detail  = str(body.get("detail", ""))
    msg = f"[CLIENT] user={user} | {action} | {detail}"
    if level == "ERROR":
        logger.error(msg)
    elif level == "WARN":
        logger.warning(msg)
    else:
        logger.info(msg)
    return {"ok": True}


@app.get("/api/ping")
async def ping():
    connected = await ensure_db()
    if not connected:
        return JSONResponse(
            content={"ok": False, "error": "MongoDB not connected. Check MONGO_URI on Render.", "db": MONGO_DB},
            status_code=503
        )
    # ensure_db() already verified the connection with a fresh ping internally
    # (in a worker thread) — no need to block the event loop again here.
    return {"ok": True, "db": MONGO_DB, "server": "MongoDB Atlas", "connected": True}

@app.get("/api/companies")
def list_companies():
    return JSONResponse({"companies":[{"id":"rio","name":"GREEN DIGITALS"},{"id":"rainbow","name":"RAINBOW UMBRELLAS"}]})

@app.post("/api/sync-rainbow")
def sync_rainbow():
    if not _client: return JSONResponse({"ok":False,"error":"DB not connected"},status_code=503)
    rio_db=_client[MONGO_DB]; rb_db=_client[MONGO_DB_RAINBOW]
    results={}
    for c in ["clients","green_digital_clients","products","categories","sizes"]:
        try:
            docs=list(rio_db[c].find({},{"_id":0}))
            if docs: rb_db[c].delete_many({}); rb_db[c].insert_many(docs); results[c]=len(docs)
            else: results[c]=0
        except Exception as e: results[c]=f"err:{e}"
    return JSONResponse({"ok":True,"synced":results})

@app.get("/api/debug")
async def debug_info():
    """Public debug endpoint — shows connection state without exposing credentials"""
    safe_uri = re.sub(r':(.*?)@', ':***@', MONGO_URI) if MONGO_URI else "NOT SET"
    return JSONResponse(content={
        "mongo_uri_set": bool(MONGO_URI),
        "mongo_uri_masked": safe_uri[:80] if MONGO_URI else "NOT SET",
        "mongo_db": MONGO_DB,
        "db_connected": _db_connected,
        "hint": "If db_connected=false, go to MongoDB Atlas → Network Access → Add 0.0.0.0/0"
    })

# ─────────────────────────────────────────────
#  SALES RECORDS
# ─────────────────────────────────────────────
@app.get("/api/sales")
async def get_sales(
    limit: int = Query(2000, ge=1, le=5000),
    skip: int = Query(0, ge=0),
    fy: Optional[str] = Query(None),
    fr: Optional[str] = Query(None, alias="from"),
    to: Optional[str] = Query(None),
    scope: Optional[str] = Query(None),
    user: Optional[str] = Query(None)
):
    if not await ensure_db():
        return JSONResponse(content=[], status_code=503)
    try:
        query = {}
        if fy:
            fy_from, fy_to = fy_range(fy)
            if fy_from and fy_to:
                query = {"$or": [
                    {"FY": fy},
                    {"$and": [{"FY": {"$in": [None, ""]}}, {"OrderDate": {"$gte": fy_from, "$lte": fy_to}}]}
                ]}
        if fr or to:
            # OrderDate stored as YYYY-MM-DD — filter by range
            date_q = {}
            if fr: date_q["$gte"] = fr
            if to: date_q["$lte"] = to
            if query:
                query = {"$and": [query, {"OrderDate": date_q}]}
            else:
                query["OrderDate"] = date_q
        if scope == "own" and user:
            query["createdBy"] = user
        rows = list(col("sales_records").find(query, {"_id": 0})
                    .sort("SNo", DESCENDING).skip(skip).limit(limit))
        return JSONResponse(content=rows)
    except Exception as e:
        logger.error(f"get_sales error: {e}")
        return JSONResponse(content=[], status_code=500)

def _sanitize_sale_items(items):
    """Validates/cleans the Rio dynamic multi-product Items array before storage.
    Unlimited products (Add Product button) — each item is a distinct product row
    with its own size/qty/rate/GST rate, unlike the old fixed Size1/2/3 fields."""
    if not isinstance(items, list):
        return []
    out = []
    for it in items:
        if not isinstance(it, dict):
            continue
        qty = to_float(it.get("Qty"), 0.0)
        rate = to_float(it.get("Rate"), 0.0)
        if not (it.get("ProductId") or qty or rate):
            continue
        out.append({
            "ProductId":   it.get("ProductId", ""),
            "ProductName": it.get("ProductName", ""),
            "Size":        it.get("Size", ""),
            "Qty":         qty,
            "Rate":        rate,
            "Amt":         to_float(it.get("Amt"), 0.0),
            "GSTRate":     to_float(it.get("GSTRate"), 0.0),
        })
    return out

@app.post("/api/sales")
async def post_sales(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    sno = next_id("sales_records", "SNo")
    doc = {
        "SNo": sno,
        "createdBy":          b.get("createdBy", ""),
        "Customer":           b.get("Customer", ""),
        "Category":           b.get("Category", ""),
        "ProductSize":        b.get("ProductSize", ""),
        "Size1":              b.get("Size1", ""),
        "Qty1":               b.get("Qty1", ""),
        "Size2":              b.get("Size2", ""),
        "Qty2":               b.get("Qty2", ""),
        "Size3":              b.get("Size3", ""),
        "Qty3":               b.get("Qty3", ""),
        "Items":              _sanitize_sale_items(b.get("Items")),
        "BillingType":        b.get("BillingType", ""),
        "JobName":            b.get("JobName", ""),
        "OrderDate":          b.get("OrderDate"),
        "TotalAmount":        to_float(b.get("TotalAmount")),
        "AdvanceAmt":         to_float(b.get("AdvanceAmt")),
        "AdvanceDate":        b.get("AdvanceDate"),
        "AdvanceMode":        b.get("AdvanceMode", ""),
        "AdvanceDetails":     b.get("AdvanceDetails", ""),
        "BalanceSettledAmt":  to_float(b.get("BalanceSettledAmt")),
        "BalanceDate":        b.get("BalanceDate"),
        "BalanceMode":        b.get("BalanceMode", ""),
        "Balance1Details":    b.get("Balance1Details", ""),
        "Balance2Amt":        to_float(b.get("Balance2Amt")),
        "Balance2Date":       b.get("Balance2Date"),
        "Balance2Mode":       b.get("Balance2Mode", ""),
        "Balance2Details":    b.get("Balance2Details", ""),
        "Balance3Amt":        to_float(b.get("Balance3Amt")),
        "Balance3Date":       b.get("Balance3Date"),
        "Balance3Mode":       b.get("Balance3Mode", ""),
        "Balance3Details":    b.get("Balance3Details", ""),
        "Balance4Amt":        to_float(b.get("Balance4Amt")),
        "Balance4Date":       b.get("Balance4Date"),
        "Balance4Mode":       b.get("Balance4Mode", ""),
        "Balance4Details":    b.get("Balance4Details", ""),
        "RemainingBalance":   to_float(b.get("RemainingBalance")),
        "CustomerGST":        b.get("CustomerGST", ""),
        "CustomerStateCode":  b.get("CustomerStateCode", ""),
        "ProductId":          to_int(b.get("ProductId")),
        "ProductId2":         to_int(b.get("ProductId2")),
        "Rate1":              to_float(b.get("Rate1")),
        "Rate2":              to_float(b.get("Rate2")),
        "Rate3":              to_float(b.get("Rate3")),
        "Amt1":               to_float(b.get("Amt1"), 0.0),
        "Amt2":               to_float(b.get("Amt2"), 0.0),
        "Amt3":               to_float(b.get("Amt3"), 0.0),
        "GSTRate1":           to_float(b.get("GSTRate1"), 0.0),
        "GSTRate2":           to_float(b.get("GSTRate2"), 0.0),
        "GSTRate3":           to_float(b.get("GSTRate3"), 0.0),
        "InvoiceNo":          b.get("InvoiceNo", ""),
        "PFDesc":             b.get("PFDesc", ""),
        "PFAmt":              to_float(b.get("PFAmt"), 0.0),
        "PFGst":              to_float(b.get("PFGst"), 0.0),
        "PFTotal":            to_float(b.get("PFTotal"), 0.0),
        "FY":                 fy_from_date(b.get("OrderDate") or datetime.now().strftime("%Y-%m-%d")),
        "UpdatedAt":          datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    col("sales_records").insert_one(doc)
    # Auto-add client
    if doc["Customer"]:
        shared_col("green_digital_clients").update_one(
            {"ClientName": doc["Customer"]},
            {"$setOnInsert": {"Id": next_id("green_digital_clients"), "ClientName": doc["Customer"], "createdBy": doc.get("createdBy", "")}},
            upsert=True
        )
    # Ledger credits
    payments = [
        {"Amt": doc["AdvanceAmt"],        "Date": doc["AdvanceDate"],  "Mode": doc["AdvanceMode"]},
        {"Amt": doc["BalanceSettledAmt"], "Date": doc["BalanceDate"],  "Mode": doc["BalanceMode"]},
        {"Amt": doc["Balance2Amt"],       "Date": doc["Balance2Date"], "Mode": doc["Balance2Mode"]},
        {"Amt": doc["Balance3Amt"],       "Date": doc["Balance3Date"], "Mode": doc["Balance3Mode"]},
        {"Amt": doc["Balance4Amt"],       "Date": doc["Balance4Date"], "Mode": doc["Balance4Mode"]},
    ]
    set_sales_ledger_credits(sno, doc["Customer"], doc["JobName"], payments)
    return ok({"ok": True, "SNo": sno})

@app.put("/api/sales/{sno}")
async def put_sales(sno: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    update = {
        "Customer":           b.get("Customer", ""),
        "Category":           b.get("Category", ""),
        "ProductSize":        b.get("ProductSize", ""),
        "Size1":              b.get("Size1", ""),
        "Qty1":               b.get("Qty1", ""),
        "Size2":              b.get("Size2", ""),
        "Qty2":               b.get("Qty2", ""),
        "Size3":              b.get("Size3", ""),
        "Qty3":               b.get("Qty3", ""),
        "Items":              _sanitize_sale_items(b.get("Items")),
        "BillingType":        b.get("BillingType", ""),
        "JobName":            b.get("JobName", ""),
        "OrderDate":          b.get("OrderDate"),
        "TotalAmount":        to_float(b.get("TotalAmount")),
        "AdvanceAmt":         to_float(b.get("AdvanceAmt")),
        "AdvanceDate":        b.get("AdvanceDate"),
        "AdvanceMode":        b.get("AdvanceMode", ""),
        "AdvanceDetails":     b.get("AdvanceDetails", ""),
        "BalanceSettledAmt":  to_float(b.get("BalanceSettledAmt")),
        "BalanceDate":        b.get("BalanceDate"),
        "BalanceMode":        b.get("BalanceMode", ""),
        "Balance1Details":    b.get("Balance1Details", ""),
        "Balance2Amt":        to_float(b.get("Balance2Amt")),
        "Balance2Date":       b.get("Balance2Date"),
        "Balance2Mode":       b.get("Balance2Mode", ""),
        "Balance2Details":    b.get("Balance2Details", ""),
        "Balance3Amt":        to_float(b.get("Balance3Amt")),
        "Balance3Date":       b.get("Balance3Date"),
        "Balance3Mode":       b.get("Balance3Mode", ""),
        "Balance3Details":    b.get("Balance3Details", ""),
        "Balance4Amt":        to_float(b.get("Balance4Amt")),
        "Balance4Date":       b.get("Balance4Date"),
        "Balance4Mode":       b.get("Balance4Mode", ""),
        "Balance4Details":    b.get("Balance4Details", ""),
        "RemainingBalance":   to_float(b.get("RemainingBalance")),
        "CustomerGST":        b.get("CustomerGST", ""),
        "CustomerStateCode":  b.get("CustomerStateCode", ""),
        "ProductId":          to_int(b.get("ProductId")),
        "ProductId2":         to_int(b.get("ProductId2")),
        "Rate1":              to_float(b.get("Rate1")),
        "Rate2":              to_float(b.get("Rate2")),
        "Rate3":              to_float(b.get("Rate3")),
        "Amt1":               to_float(b.get("Amt1"), 0.0),
        "Amt2":               to_float(b.get("Amt2"), 0.0),
        "Amt3":               to_float(b.get("Amt3"), 0.0),
        "GSTRate1":           to_float(b.get("GSTRate1"), 0.0),
        "GSTRate2":           to_float(b.get("GSTRate2"), 0.0),
        "GSTRate3":           to_float(b.get("GSTRate3"), 0.0),
        "PFDesc":             b.get("PFDesc", ""),
        "PFAmt":              to_float(b.get("PFAmt"), 0.0),
        "PFGst":              to_float(b.get("PFGst"), 0.0),
        "PFTotal":            to_float(b.get("PFTotal"), 0.0),
        "FY":                 fy_from_date(b.get("OrderDate") or datetime.now().strftime("%Y-%m-%d")),
        "UpdatedAt":          datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    col("sales_records").update_one({"SNo": sno}, {"$set": update})
    payments = [
        {"Amt": update["AdvanceAmt"],        "Date": update["AdvanceDate"],  "Mode": update["AdvanceMode"]},
        {"Amt": update["BalanceSettledAmt"], "Date": update["BalanceDate"],  "Mode": update["BalanceMode"]},
        {"Amt": update["Balance2Amt"],       "Date": update["Balance2Date"], "Mode": update["Balance2Mode"]},
        {"Amt": update["Balance3Amt"],       "Date": update["Balance3Date"], "Mode": update["Balance3Mode"]},
        {"Amt": update["Balance4Amt"],       "Date": update["Balance4Date"], "Mode": update["Balance4Mode"]},
    ]
    set_sales_ledger_credits(sno, update["Customer"], update["JobName"], payments)
    return ok()

@app.delete("/api/sales/{sno}")
async def delete_sales(sno: int):
    if not await ensure_db(): return err("Database not connected", 503)
    # Find affected accounts before deleting so we can recalc their balances
    affected_entries = list(col("account_ledger").find(
        {"SalesRef": sno}, {"AccountName": 1, "FY": 1}
    ))
    affected = set((e["AccountName"], e["FY"]) for e in affected_entries if e.get("AccountName") and e.get("FY"))
    col("account_ledger").delete_many({"SalesRef": sno})
    col("sales_records").delete_one({"SNo": sno})
    # Recalculate running balances for all affected accounts
    for acct, fy in affected:
        recalc_ledger_balances(acct, fy)
    return ok()

@app.post("/api/sales/{sno}/invoiceno")
async def patch_sales_invoiceno(sno: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    col("sales_records").update_one({"SNo": sno}, {"$set": {"InvoiceNo": b.get("InvoiceNo", "")}})
    return ok()

# ─────────────────────────────────────────────
#  EXPENSES
# ─────────────────────────────────────────────
@app.get("/api/expenses")
async def get_expenses(scope: Optional[str] = Query(None), user: Optional[str] = Query(None)):
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    query = {}
    if scope == "own" and user:
        query["createdBy"] = user
    rows = list(col("daily_expenses").find(query, {"_id": 0}).sort([("ExpDate", DESCENDING), ("Id", DESCENDING)]))
    return JSONResponse(content=rows)

@app.post("/api/expenses")
async def post_expenses(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_id = next_id("daily_expenses")
    amt = to_float(b.get("Amount"), 0.0)
    doc = {
        "Id":          new_id,
        "createdBy":   (b.get("createdBy") or "").strip(),
        "ExpDate":     b.get("ExpDate"),
        "Category":    b.get("Category", ""),
        "SubCategory": b.get("SubCategory", ""),
        "PaymentMode": b.get("PaymentMode", ""),
        "Description": b.get("Description", ""),
        "Amount":      amt,
    }
    col("daily_expenses").insert_one(doc)
    # Auto-create ledger debit
    pm = (b.get("PaymentMode") or "").strip()
    acct = ledger_account_for(pm)
    if acct and new_id:
        exp_date = (b.get("ExpDate") or "").strip()
        fy = fy_from_date(exp_date)
        if fy:
            sub_cat = (b.get("SubCategory") or "").strip()
            desc_str = (b.get("Description") or "").strip()
            desc = f"Expense: {sub_cat} — {desc_str}" if desc_str else f"Expense: {sub_cat}"
            last = col("account_ledger").find_one(
                {"AccountName": acct, "FY": fy},
                sort=[("EntryDate", DESCENDING), ("Id", DESCENDING)]
            )
            prev_bal = to_float(last["Balance"]) if last else 0.0
            new_bal  = prev_bal - amt
            led_id   = next_id("account_ledger")
            col("account_ledger").insert_one({
                "Id": led_id, "AccountName": acct, "EntryDate": exp_date,
                "Description": desc, "CreditAmt": 0, "DebitAmt": amt,
                "Balance": new_bal, "EntryType": "Expense", "FY": fy,
                "ExpenseRef": new_id, "SalesRef": None
            })
    return ok({"ok": True, "id": new_id})


@app.put("/api/expense/{exp_id}")
@app.put("/api/billing/expense/{exp_id}")
async def put_expense(exp_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    amt = to_float(b.get("Amount"), 0.0)
    result = col("daily_expenses").update_one(
        {"Id": exp_id},
        {"$set": {
            "ExpDate":     b.get("ExpDate", ""),
            "Category":    b.get("Category", ""),
            "SubCategory": b.get("SubCategory", ""),
            "PaymentMode": b.get("PaymentMode", ""),
            "Description": b.get("Description", ""),
            "Amount":      amt,
        }}
    )
    if result.matched_count == 0:
        return err("Expense not found", 404)
    return ok({"success": True})

@app.delete("/api/expenses/{exp_id}")
async def delete_expense(exp_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("account_ledger").delete_many({"ExpenseRef": exp_id})
    col("daily_expenses").delete_one({"Id": exp_id})
    return ok()

# ─────────────────────────────────────────────
#  NOTES
# ─────────────────────────────────────────────
# ─────────────────────────────────────────────
#  FOLLOWUPS
# ─────────────────────────────────────────────
@app.get("/api/followups")
async def get_followups():
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("followups").find({}, {"_id": 0}).sort([("IsAddressed", ASCENDING), ("FollowupDate", ASCENDING), ("Id", ASCENDING)]))
    return JSONResponse(content=rows)

@app.post("/api/followups")
async def post_followups(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_id = next_id("followups")
    col("followups").insert_one({
        "Id": new_id,
        "FollowupDate": b.get("FollowupDate"),
        "Priority":     b.get("Priority", ""),
        "FollowupText": b.get("FollowupText", ""),
        "IsAddressed":  0,
    })
    return ok()


# ─────────────────────────────────────────────
#  CONTACTS
# ─────────────────────────────────────────────

@app.get("/api/contacts")
async def get_contacts(
    search: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
    user: Optional[str] = Query(None)
):
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if search:
        rgx = {"$regex": search, "$options": "i"}
        query["$or"] = [{"Name": rgx}, {"Phone": rgx}, {"Place": rgx}]
    if category and category != "all":
        query["Category"] = category
    skip = (page - 1) * limit
    total = shared_col("contacts").count_documents(query)
    rows = list(shared_col("contacts").find(query, {"_id": 0})
                .sort("Name", 1).skip(skip).limit(limit))
    return JSONResponse(content={"total": total, "page": page, "limit": limit, "rows": rows})

@app.post("/api/contacts")
async def save_contact(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    b.pop("_id", None)
    contact_id = b.get("Id")
    if contact_id:
        # Update existing
        shared_col("contacts").update_one({"Id": contact_id}, {"$set": b})
    else:
        # Check duplicate phone
        phone = b.get("Phone", "").strip()
        if phone:
            existing = shared_col("contacts").find_one({"Phone": phone}, {"_id": 0})
            if existing:
                return err(f"Phone {phone} already exists for {existing.get('Name','')}", 409)
        new_id = next_id("contacts")
        b["Id"] = new_id
        shared_col("contacts").insert_one(b)
    return ok({"Id": b.get("Id")})

@app.delete("/api/contacts/{contact_id}")
async def delete_contact(contact_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    shared_col("contacts").delete_one({"Id": contact_id})
    return ok()

@app.get("/api/contacts/categories")
async def get_contact_categories():
    if not await ensure_db(): return err("Database not connected", 503)
    # Get custom categories + defaults
    custom = list(shared_col("contact_categories").find({}, {"_id": 0}).sort("Name", 1))
    defaults = [
        {"Name": "Customer", "Color": "#1565c0"},
        {"Name": "Vendor",   "Color": "#e65100"},
        {"Name": "Staff",    "Color": "#2e7d32"},
        {"Name": "Other",    "Color": "#6a1b9a"}
    ]
    # Merge: custom overrides defaults if same name
    custom_names = {c["Name"] for c in custom}
    merged = [d for d in defaults if d["Name"] not in custom_names] + custom
    merged.sort(key=lambda x: x["Name"])
    return JSONResponse(content=merged)

@app.post("/api/contacts/categories")
async def save_contact_category(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    name = b.get("Name", "").strip()
    if not name: return err("Category name required")
    color = b.get("Color", "#607d8b")
    shared_col("contact_categories").update_one(
        {"Name": name}, {"$set": {"Name": name, "Color": color}}, upsert=True)
    return ok()

@app.delete("/api/contacts/categories/{name}")
async def delete_contact_category(name: str):
    if not await ensure_db(): return err("Database not connected", 503)
    shared_col("contact_categories").delete_one({"Name": name})
    return ok()


@app.put("/api/followups/{fid}/address")
async def address_followup(fid: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("followups").update_one({"Id": fid}, {"$set": {"IsAddressed": 1}})
    return ok()

@app.put("/api/followups/{fid}/reopen")
async def reopen_followup(fid: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_date = b.get("FollowupDate") or datetime.now().strftime("%Y-%m-%d")
    col("followups").update_one({"Id": fid}, {"$set": {"IsAddressed": 0, "FollowupDate": new_date}})
    return ok()

@app.put("/api/followups/{fid}")
async def put_followup(fid: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    col("followups").update_one({"Id": fid}, {"$set": {
        "FollowupDate": b.get("FollowupDate"),
        "Priority":     b.get("Priority", ""),
        "FollowupText": b.get("FollowupText", ""),
    }})
    return ok()

@app.delete("/api/followups/{fid}")
async def delete_followup(fid: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("followups").delete_one({"Id": fid})
    return ok()

# ─────────────────────────────────────────────
#  CLIENTS
# ─────────────────────────────────────────────
@app.get("/api/clients")
async def get_clients():
    # Clients list is a shared lookup — always return all (used for sales dropdown autocomplete)
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(shared_col("green_digital_clients").find({}, {"_id": 0, "ClientName": 1}).sort("ClientName", ASCENDING))
    return JSONResponse(content=[r["ClientName"] for r in rows if r.get("ClientName")])

@app.get("/api/rio_clients")
async def get_rio_clients(q: Optional[str] = Query(None)):
    """Alias for /api/billing/customers — used by customer autocomplete."""
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    query = {}
    if q: query["Name"] = {"$regex": q, "$options": "i"}
    rows = list(shared_col("green_digital_clients").find(query, {"_id": 0}).sort("ClientName", ASCENDING))
    # Rename ClientName → Name for billing compatibility
    result = [{"Id": r.get("Id"), "Name": r.get("ClientName", r.get("Name", "")),
               "Mobile": r.get("Mobile",""), "GSTNo": r.get("GSTNo",""),
               "State": r.get("State",""), "StateCode": r.get("StateCode",""),
               "Type": r.get("Type","")} for r in rows]
    return JSONResponse(content=result)


@app.post("/api/clients")
async def post_clients(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    name = (b.get("ClientName") or "").strip()
    created_by = (b.get("createdBy") or "").strip()
    if name:
        shared_col("green_digital_clients").update_one(
            {"ClientName": name},
            {"$setOnInsert": {"Id": next_id("green_digital_clients"), "ClientName": name, "createdBy": created_by}},
            upsert=True
        )
    return ok()

# ─────────────────────────────────────────────
#  CATEGORIES
# ─────────────────────────────────────────────
@app.delete("/api/clients/{client_name:path}")
async def delete_client(client_name: str):
    """Delete a client from the sales tracker clientsList."""
    if not await ensure_db(): return JSONResponse(content={"error":"DB offline"}, status_code=503)
    name = client_name.strip()
    shared_col("green_digital_clients").delete_one({"ClientName": {"$regex": f"^{re.escape(name)}$", "$options": "i"}})
    return ok({"success": True, "deleted": name})


@app.get("/api/categories")
async def get_categories():
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("expense_categories").distinct("CategoryName"))
    return JSONResponse(content=sorted(rows))

@app.get("/api/expense_categories")
async def get_expense_categories_alias():
    """Alias for /api/categories — used by mobile/expense dropdown."""
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("expense_categories").find({}, {"_id": 0}).sort(
        [("CategoryName", ASCENDING), ("SubCategoryName", ASCENDING)]))
    return JSONResponse(content=rows)


@app.get("/api/categories/all")
async def get_categories_all():
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("expense_categories").find({}, {"_id": 0}).sort([("CategoryName", ASCENDING), ("SubCategoryName", ASCENDING)]))
    from collections import defaultdict
    mp = defaultdict(list)
    for r in rows:
        mp[r["CategoryName"]].append(r["SubCategoryName"])
    return JSONResponse(content=[{"category": k, "subcats": v} for k, v in mp.items()])

@app.get("/api/categories/subcats")
async def get_subcats(cat: str = Query("")):
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("expense_categories").find({"CategoryName": cat}, {"_id": 0, "SubCategoryName": 1}).sort("SubCategoryName", ASCENDING))
    subs = [r["SubCategoryName"] for r in rows]
    return JSONResponse(content=subs if subs else ["Other"])

@app.post("/api/categories")
async def post_category(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    cn = (b.get("CategoryName") or "").strip()
    sn = (b.get("SubCategoryName") or "").strip()
    if cn and sn:
        exists = col("expense_categories").find_one({"CategoryName": cn, "SubCategoryName": sn})
        if not exists:
            new_id = next_id("expense_categories")
            col("expense_categories").insert_one({"Id": new_id, "CategoryName": cn, "SubCategoryName": sn})
    return ok()

@app.post("/api/categories/sync")
async def sync_categories(request: Request):
    rows = await request.json()
    inserted = 0
    for row in (rows if isinstance(rows, list) else []):
        cn = (row.get("CategoryName") or "").strip()
        sn = (row.get("SubCategoryName") or "").strip()
        if cn and sn:
            exists = col("expense_categories").find_one({"CategoryName": cn, "SubCategoryName": sn})
            if not exists:
                new_id = next_id("expense_categories")
                col("expense_categories").insert_one({"Id": new_id, "CategoryName": cn, "SubCategoryName": sn})
                inserted += 1
    return ok({"ok": True, "inserted": inserted})

# NOTE: must stay ABOVE /categories/{cat_id}, or 'byname' is read as a category id (HTTP 422) and Manage Categories deletes fail.
@app.delete("/api/categories/byname")
@app.delete("/api/billing/categories/byname")
async def delete_category_byname(category: str = Query(""), subcategory: str = Query("")):
    """Delete a category or subcategory by name."""
    if not await ensure_db(): return err("Database not connected", 503)
    try:
        if subcategory:
            # Delete specific subcategory
            col("expense_categories").delete_many({"CategoryName": category, "SubCategoryName": subcategory})
        elif category:
            # Check if any expenses use this category
            count = col("daily_expenses").count_documents({"Category": category})
            if count > 0:
                return err(f"Cannot delete: {count} expense records use this category", 400)
            col("expense_categories").delete_many({"CategoryName": category})
        return ok({"success": True})
    except Exception as e:
        return err(str(e), 500)

@app.delete("/api/categories/{cat_id}")
async def delete_category(cat_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("expense_categories").delete_one({"Id": cat_id})
    return ok()

# ─────────────────────────────────────────────
#  JOBS
# ─────────────────────────────────────────────
@app.get("/api/jobs")
async def get_jobs(fr: Optional[str] = Query(None, alias="from"), to: Optional[str] = Query(None)):
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    query = {}
    if fr: query["ConfirmedDate"] = {"$gte": fr}
    if to: query.setdefault("ConfirmedDate", {})["$lte"] = to
    rows = list(col("jobs").find(query, {"_id": 0}).sort("Id", DESCENDING))
    return JSONResponse(content=rows)

@app.post("/api/jobs")
async def post_jobs(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_id = next_id("jobs")
    # Auto-generate JobNo if not provided: J001, J002, ...
    job_no = (b.get("JobNo") or "").strip()
    if not job_no:
        pipeline = [{"$group": {"_id": None, "max": {"$max": "$Id"}}}]
        res = list(col("jobs").aggregate(pipeline))
        max_id = to_int(res[0]["max"]) if res else 0
        job_no = f"J{(max_id + 1):03d}"
    col("jobs").insert_one({
        "Id":           new_id,
        "JobNo":        job_no,
        "Customer":     b.get("Customer", ""),
        "JobName":      b.get("JobName", ""),
        "ConfirmedDate":b.get("ConfirmedDate"),
        "ProductSize":  b.get("ProductSize", ""),
        "Qty":          to_int(b.get("Qty")),
        "Status":       b.get("Status", ""),
        "DispatchDate": b.get("DispatchDate"),
    })
    return ok({"ok": True, "id": new_id, "jobNo": job_no})

@app.put("/api/jobs/{job_id}")
async def put_jobs(job_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    update = {
        "Customer":     b.get("Customer", ""),
        "JobName":      b.get("JobName", ""),
        "ConfirmedDate":b.get("ConfirmedDate"),
        "ProductSize":  b.get("ProductSize", ""),
        "Qty":          to_int(b.get("Qty")),
        "Status":       b.get("Status", ""),
        "DispatchDate": b.get("DispatchDate"),
    }
    # Only update JobNo if provided (don't overwrite existing)
    if b.get("JobNo"):
        update["JobNo"] = b.get("JobNo")
    col("jobs").update_one({"Id": job_id}, {"$set": update})
    return ok()

@app.delete("/api/jobs/{job_id}")
async def delete_jobs(job_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("jobs").delete_one({"Id": job_id})
    return ok()

# ─────────────────────────────────────────────
#  ACCOUNT BALANCES
# ─────────────────────────────────────────────
@app.get("/api/accountbalances")
async def get_acct_balances():
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("account_balances").find({}, {"_id": 0}).sort([("EntryDate", DESCENDING), ("Id", DESCENDING)]))
    return JSONResponse(content=rows)

@app.post("/api/accountbalances")
async def post_acct_balance(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_id = next_id("account_balances")
    col("account_balances").insert_one({
        "Id":          new_id,
        "AccountName": b.get("AccountName", ""),
        "EntryDate":   b.get("EntryDate"),
        "Balance":     to_float(b.get("Balance"), 0.0),
        "Notes":       b.get("Notes", ""),
    })
    return ok({"ok": True, "id": new_id})

@app.delete("/api/accountbalances/{ab_id}")
async def delete_acct_balance(ab_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("account_balances").delete_one({"Id": ab_id})
    return ok()

# ─────────────────────────────────────────────
#  LEDGER
# ─────────────────────────────────────────────
@app.get("/api/ledger/debug")
async def ledger_debug():
    total = col("account_ledger").count_documents({})
    rows = list(col("account_ledger").find({}, {"_id": 0}).sort("Id", DESCENDING).limit(20))
    return JSONResponse(content={"total": total, "rows": rows})

@app.get("/api/ledger/prev-closing")
async def ledger_prev_closing(fy: str = Query("")):
    if not fy:
        return JSONResponse(content=[])
    fy_year = int(fy.split("-")[0])
    prev_fy = f"{fy_year-1}-{str(fy_year)[-2:]}"
    result = []
    for acct in get_account_names() + ["Cash Balance"]:
        last = col("account_ledger").find_one(
            {"AccountName": acct, "FY": prev_fy},
            sort=[("EntryDate", DESCENDING), ("Id", DESCENDING)]
        )
        bal = to_float(last["Balance"]) if last else 0.0
        result.append({"AccountName": acct, "ClosingBalance": bal})
    return JSONResponse(content=result)

@app.get("/api/ledger/opening")
async def get_ledger_opening(fy: str = Query("")):
    if not fy:
        return JSONResponse(content=[])
    rows = list(col("account_opening_balances").find({"FY": fy}, {"_id": 0}))
    return JSONResponse(content=rows)

@app.post("/api/ledger/opening")
async def post_ledger_opening(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    fy = (b.get("FY") or "").strip()
    if not fy:
        return err("FY required")
    for acct in get_account_names() + ["Cash Balance"]:
        val = to_float(b.get(acct), 0.0)
        exists = col("account_opening_balances").find_one({"AccountName": acct, "FY": fy})
        if exists:
            col("account_opening_balances").update_one(
                {"AccountName": acct, "FY": fy},
                {"$set": {"OpeningBal": val}}
            )
        else:
            col("account_opening_balances").insert_one({"AccountName": acct, "FY": fy, "OpeningBal": val})
    return ok()

@app.delete("/api/ledger/clear-opening")
async def clear_ledger_opening(fy: str = Query("")):
    if not await ensure_db(): return err("Database not connected", 503)
    if not fy:
        return ok({"ok": False})
    col("account_ledger").delete_many({"EntryType": "Opening", "FY": fy})
    col("account_opening_balances").delete_many({"FY": fy})
    return ok()

@app.get("/api/ledger")
async def get_ledger(
    account: Optional[str] = Query(None),
    fy: Optional[str] = Query(None),
    month: Optional[str] = Query(None)
):
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    if not fy:
        return JSONResponse(content=[])
    query = {"FY": fy}
    if account: query["AccountName"] = account
    if month:   query["EntryDate"] = {"$regex": f"^{month}"}
    rows = list(col("account_ledger").find(query, {"_id": 0}).sort([("EntryDate", ASCENDING), ("Id", ASCENDING)]))
    return JSONResponse(content=rows)

@app.post("/api/ledger")
async def post_ledger(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    acct  = (b.get("AccountName") or "").strip()
    dt    = (b.get("EntryDate") or "").strip() or datetime.now().strftime("%Y-%m-%d")
    desc  = (b.get("Description") or "").strip()
    cr    = to_float(b.get("CreditAmt"), 0.0)
    dr    = to_float(b.get("DebitAmt"), 0.0)
    etype = (b.get("EntryType") or "Manual").strip()
    fy    = (b.get("FY") or "").strip()
    if not acct: return err("AccountName required")
    if not fy:   return err("FY required")
    if cr > 0 and dr > 0:
        return err("A ledger entry can only be a Credit or a Debit, not both — please enter one amount and leave the other at 0")
    if etype == "Opening":
        new_bal = cr - dr
    else:
        last = col("account_ledger").find_one(
            {"AccountName": acct, "FY": fy},
            sort=[("EntryDate", DESCENDING), ("Id", DESCENDING)]
        )
        if last:
            prev = to_float(last["Balance"], 0.0)
        else:
            ob = col("account_opening_balances").find_one({"AccountName": acct, "FY": fy})
            prev = to_float(ob["OpeningBal"]) if ob else 0.0
        new_bal = prev + cr - dr
    new_id = next_id("account_ledger")
    col("account_ledger").insert_one({
        "Id": new_id, "AccountName": acct, "EntryDate": dt,
        "Description": desc, "CreditAmt": cr, "DebitAmt": dr,
        "Balance": new_bal, "EntryType": etype, "FY": fy,
        "ExpenseRef": None, "SalesRef": None
    })
    return ok({"ok": True, "balance": new_bal})

@app.delete("/api/ledger/reset")
async def ledger_reset():
    if not await ensure_db(): return err("Database not connected", 503)
    col("account_ledger").delete_many({})
    col("account_opening_balances").delete_many({})
    return ok()

@app.delete("/api/ledger/{led_id}")
async def delete_ledger_entry(led_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("account_ledger").delete_one({"Id": led_id})
    return ok()

@app.post("/api/ledger/migrate")
async def ledger_migrate(request: Request):
    b = await request.json()
    fy = (b.get("FY") or "").strip()
    if not fy: return err("FY required")
    fy_from, fy_to = fy_range(fy)
    exp_count = sales_count = skip_count = 0

    # Import expenses
    exp_rows = list(col("daily_expenses").find(
        {"ExpDate": {"$gte": fy_from, "$lte": fy_to}},
        {"_id": 0}
    ).sort([("ExpDate", ASCENDING), ("Id", ASCENDING)]))

    for row in exp_rows:
        exp_id = to_int(row.get("Id"))
        already = col("account_ledger").count_documents({"ExpenseRef": exp_id})
        if already > 0: skip_count += 1; continue
        pm = (row.get("PaymentMode") or "").strip()
        acct = ledger_account_for(pm)
        if not acct: skip_count += 1; continue
        exp_date = row.get("ExpDate", "")
        amt = to_float(row.get("Amount"), 0.0)
        sub_cat = (row.get("SubCategory") or "").strip()
        desc_str = (row.get("Description") or "").strip()
        desc = f"Expense: {sub_cat} — {desc_str}" if desc_str else f"Expense: {sub_cat}"
        last = col("account_ledger").find_one({"AccountName": acct, "FY": fy}, sort=[("EntryDate", DESCENDING), ("Id", DESCENDING)])
        prev = to_float(last["Balance"]) if last else 0.0
        new_bal = prev - amt
        led_id = next_id("account_ledger")
        col("account_ledger").insert_one({
            "Id": led_id, "AccountName": acct, "EntryDate": exp_date,
            "Description": desc, "CreditAmt": 0, "DebitAmt": amt,
            "Balance": new_bal, "EntryType": "Expense", "FY": fy,
            "ExpenseRef": exp_id, "SalesRef": None
        })
        exp_count += 1

    # Import sales payments
    sales_rows = list(col("sales_records").find(
        {"OrderDate": {"$gte": fy_from, "$lte": fy_to}},
        {"_id": 0}
    ).sort([("OrderDate", ASCENDING), ("SNo", ASCENDING)]))

    for row in sales_rows:
        sno = to_int(row.get("SNo"))
        already = col("account_ledger").count_documents({"SalesRef": sno})
        if already > 0: skip_count += 1; continue
        cust = (row.get("Customer") or "").strip()
        job  = (row.get("JobName") or "").strip()
        jn_str = f" — {job}" if job else ""
        desc = f"Sales: {cust}{jn_str}"
        payments = [
            {"Amt": row.get("AdvanceAmt"),        "Date": row.get("AdvanceDate"),  "Mode": row.get("AdvanceMode","")},
            {"Amt": row.get("BalanceSettledAmt"), "Date": row.get("BalanceDate"),  "Mode": row.get("BalanceMode","")},
            {"Amt": row.get("Balance2Amt"),       "Date": row.get("Balance2Date"), "Mode": row.get("Balance2Mode","")},
            {"Amt": row.get("Balance3Amt"),       "Date": row.get("Balance3Date"), "Mode": row.get("Balance3Mode","")},
            {"Amt": row.get("Balance4Amt"),       "Date": row.get("Balance4Date"), "Mode": row.get("Balance4Mode","")},
        ]
        added = False
        for pay in payments:
            amt  = to_float(pay["Amt"])
            pdate = (pay["Date"] or "").strip()
            mode = (pay["Mode"] or "").strip()
            if not amt or amt <= 0 or not pdate: continue
            acct = ledger_account_for(mode)
            if not acct: continue
            last = col("account_ledger").find_one({"AccountName": acct, "FY": fy}, sort=[("EntryDate", DESCENDING), ("Id", DESCENDING)])
            prev = to_float(last["Balance"]) if last else 0.0
            new_bal = prev + amt
            led_id = next_id("account_ledger")
            col("account_ledger").insert_one({
                "Id": led_id, "AccountName": acct, "EntryDate": pdate,
                "Description": desc, "CreditAmt": amt, "DebitAmt": 0,
                "Balance": new_bal, "EntryType": "Credit", "FY": fy,
                "ExpenseRef": None, "SalesRef": sno
            })
            added = True
            sales_count += 1
        if not added: skip_count += 1

    return ok({"ok": True, "expenseEntries": exp_count, "salesEntries": sales_count, "skipped": skip_count})

# ─────────────────────────────────────────────
#  BILLING — CUSTOMERS
# ─────────────────────────────────────────────
@app.get("/api/billing/status")
async def billing_status():
    cc = shared_col("green_digital_clients").count_documents({})
    pc = col("products").count_documents({})
    ic = col("sales_invoices").count_documents({"Status": {"$ne": "Cancelled"}})
    return JSONResponse(content={"ready": True, "server": "MongoDB Atlas", "database": MONGO_DB, "version": "3.0", "customers": cc, "products": pc, "invoices": ic})

@app.get("/api/billing/customers")
async def billing_get_customers(q: Optional[str] = Query(None), scope: Optional[str] = Query(None), user: Optional[str] = Query(None)):
    if q:
        query = {"$or": [
            {"ClientName": {"$regex": q, "$options": "i"}},
            {"Mobile": {"$regex": q, "$options": "i"}},
            {"GSTNo": {"$regex": q, "$options": "i"}},
        ]}
    else:
        query = {}
    # Customers are shared data — do NOT filter by createdBy/scope.
    # Scope (own/all) applies only to transactional data (sales, invoices, quotations).
    rows = list(shared_col("green_digital_clients").find(query, {"_id": 0}).sort("ClientName", ASCENDING))
    # Rename ClientName → Name for billing compatibility
    result = []
    for r in rows:
        result.append({
            "Id": r.get("Id"), "Name": r.get("ClientName",""),
            "BillToAddress": r.get("BillToAddress",""), "ShipToAddress": r.get("ShipToAddress",""),
            "State": r.get("State",""), "StateCode": r.get("StateCode",""),
            "Mobile": r.get("Mobile",""), "GSTNo": r.get("GSTNo",""),
            "Email": r.get("Email",""), "CustomerType": r.get("CustomerType",""),
        })
    return JSONResponse(content=result)

@app.post("/api/billing/customers")
async def billing_post_customer(request: Request):
    b = await request.json()
    name = (b.get("Name") or "").strip()
    if not name: return err("Name required")
    existing = shared_col("green_digital_clients").find_one({"ClientName": {"$regex": f"^{re.escape(name)}$", "$options": "i"}})
    update_doc = {
        "BillToAddress": b.get("BillToAddress",""), "ShipToAddress": b.get("ShipToAddress",""),
        "State": b.get("State",""), "StateCode": b.get("StateCode",""),
        "Mobile": b.get("Mobile",""), "GSTNo": b.get("GSTNo",""),
        "Email": b.get("Email",""), "CustomerType": b.get("CustomerType",""),
    }
    if existing:
        shared_col("green_digital_clients").update_one({"Id": existing["Id"]}, {"$set": update_doc})
        return ok({"success": True, "id": existing["Id"]})
    else:
        new_id = next_id("green_digital_clients")
        created_by = (b.get("createdBy") or "").strip()
        shared_col("green_digital_clients").insert_one({"Id": new_id, "ClientName": name, "createdBy": created_by, **update_doc})
        return ok({"success": True, "id": new_id})

@app.get("/api/billing/customers/byname")
async def billing_customer_byname(name: str = Query("")):
    if not name: return err("name required")
    r = shared_col("green_digital_clients").find_one({"ClientName": name}, {"_id": 0})
    if not r:
        r = shared_col("green_digital_clients").find_one({"ClientName": {"$regex": name, "$options": "i"}}, {"_id": 0})
    if not r: return err("Not found", 404)
    return JSONResponse(content={"Id": r.get("Id"), "Name": r.get("ClientName",""), **{k: r.get(k,"") for k in ["BillToAddress","ShipToAddress","State","StateCode","Mobile","GSTNo","Email","CustomerType"]}})

def _filled(v):
    return v is not None and bool(str(v).strip())

_CUST_DETAIL_FIELDS = ("BillToAddress", "ShipToAddress", "State", "StateCode", "Mobile", "GSTNo", "Email", "CustomerType")

def _cust_completeness(r):
    """Which duplicate to keep: the one with a GST number first, then a billing address, then the one with the
    most of the other details (shipping address, mobile, email, state, state code, type) filled in."""
    others = sum(1 for k in ("ShipToAddress", "Mobile", "Email", "State", "StateCode", "CustomerType") if _filled(r.get(k)))
    return (_filled(r.get("GSTNo")), _filled(r.get("BillToAddress")), others)

# NOTE: these two fixed-path routes must stay ABOVE the /{cust_id} routes - otherwise the server reads the word
# 'duplicates' as a customer id and answers HTTP 422.
@app.get("/api/billing/customers/duplicates")
async def billing_find_duplicate_customers():
    """Group existing customers by a normalized (trimmed, lowercased) name
    and return only the groups with more than one record - i.e. actual
    duplicates already sitting in the data, regardless of how they got
    there (case differences, pre-fix renames, etc.)."""
    if not await ensure_db(): return err("Database not connected", 503)
    all_custs = list(shared_col("green_digital_clients").find({}, {"_id": 0}))
    groups = {}
    for c in all_custs:
        name = (c.get("ClientName") or c.get("Name") or "").strip()
        if not name: continue
        groups.setdefault(name.lower(), []).append(c)
    dup_groups = []
    for recs in groups.values():
        if len(recs) < 2: continue
        # most complete record first (GST, then address, then the rest); on a tie the older record (lower Id) first
        recs.sort(key=lambda r: (_cust_completeness(r), -(r.get("Id") or 0)), reverse=True)
        dup_groups.append([{
            "Id": r.get("Id"), "Name": (r.get("ClientName") or r.get("Name") or "").strip(),
            "Mobile": r.get("Mobile", ""), "GSTNo": r.get("GSTNo", ""), "State": r.get("State", ""),
            "BillToAddress": r.get("BillToAddress", ""), "ShipToAddress": r.get("ShipToAddress", ""),
            "Email": r.get("Email", ""), "StateCode": r.get("StateCode", ""), "CustomerType": r.get("CustomerType", ""),
            "createdBy": r.get("createdBy", ""),
        } for r in recs])
    return JSONResponse(content={"groups": dup_groups, "count": len(dup_groups)})

@app.post("/api/billing/customers/merge-duplicates")
async def billing_merge_duplicate_customers(request: Request):
    """Merge one or more duplicate customer records into a single
    'keep' record: rewrites historical sales/invoices/quotations that
    used any of the removed records' names over to the kept record's
    current name, then deletes the removed records."""
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    keep_id = b.get("keepId")
    remove_ids = b.get("removeIds") or []
    if not keep_id or not remove_ids:
        return err("keepId and removeIds are required")
    keep = shared_col("green_digital_clients").find_one({"Id": keep_id}, {"_id": 0})
    if not keep:
        return err("Keep-customer not found", 404)
    current_name = (keep.get("ClientName") or keep.get("Name") or "").strip()
    if not current_name:
        return err("Kept customer has no name on record", 400)

    # Before anything is deleted, copy any detail the kept record is missing from the records being removed, so a GST
    # number / address / mobile held only by a duplicate is not lost. Where both have a value the kept record's wins.
    donors = []
    for rid in remove_ids:
        if rid == keep_id: continue
        d = shared_col("green_digital_clients").find_one({"Id": rid}, {"_id": 0})
        if d: donors.append(d)
    donors.sort(key=_cust_completeness, reverse=True)
    backfill = {}
    for k in _CUST_DETAIL_FIELDS:
        if not _filled(keep.get(k)):
            for d in donors:
                if _filled(d.get(k)):
                    backfill[k] = d[k]; break
    if backfill:
        shared_col("green_digital_clients").update_one({"Id": keep_id}, {"$set": backfill})
        keep.update(backfill)

    # What is written onto existing invoices / quotations: the name always, and a detail only when it HAS a value -
    # a blank never overwrites what an old invoice already says (e.g. its GST number).
    inv_update = {"CustomerName": current_name}
    for dst, src in (("CustomerGST", "GSTNo"), ("CustomerStateCode", "StateCode"), ("CustomerAddress", "BillToAddress"),
                     ("CustomerState", "State"), ("CustomerMobile", "Mobile"), ("CustomerEmail", "Email")):
        if _filled(keep.get(src)):
            inv_update[dst] = keep.get(src)
    sales_total = inv_total = quot_total = 0
    removed = []
    for rid in remove_ids:
        if rid == keep_id: continue
        rec = shared_col("green_digital_clients").find_one({"Id": rid}, {"_id": 0})
        if not rec: continue
        old_name = (rec.get("ClientName") or rec.get("Name") or "").strip()
        if old_name:
            name_regex = re.compile(f"^{re.escape(old_name)}$", re.IGNORECASE)
            sales_total += col("sales_records").update_many(
                {"Customer": name_regex}, {"$set": {"Customer": current_name}}
            ).modified_count
            inv_total += col("sales_invoices").update_many(
                {"$or": [{"CustomerId": rid}, {"CustomerName": name_regex}]}, {"$set": inv_update}
            ).modified_count
            quot_total += col("quotations").update_many(
                {"$or": [{"CustomerId": rid}, {"CustomerName": name_regex}]}, {"$set": inv_update}
            ).modified_count
        shared_col("green_digital_clients").delete_one({"Id": rid})
        removed.append(rid)

    return ok({"success": True, "removed": removed, "sales": sales_total, "invoices": inv_total, "quotations": quot_total, "carried": sorted(backfill)})

@app.get("/api/billing/customers/{cust_id}")
async def billing_get_customer(cust_id: int):
    r = shared_col("green_digital_clients").find_one({"Id": cust_id}, {"_id": 0})
    if not r: return err("Not found", 404)
    return JSONResponse(content={"Id": r.get("Id"), "Name": r.get("ClientName",""), **{k: r.get(k,"") for k in ["BillToAddress","ShipToAddress","State","StateCode","Mobile","GSTNo","Email","CustomerType"]}})

@app.put("/api/billing/customers/{cust_id}")
async def billing_put_customer(cust_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    name = (b.get("Name") or "").strip()
    if not name:
        return err("Customer name required")
    name_collision = shared_col("green_digital_clients").find_one(
        {"ClientName": {"$regex": f"^{re.escape(name)}$", "$options": "i"}, "Id": {"$ne": cust_id}},
        {"_id": 0, "Id": 1}
    )
    if name_collision:
        return err(f"Another customer already has the name \"{name}\" (Id {name_collision['Id']}). "
                    f"Use Check Duplicates to merge them instead of renaming into a collision.", 409)
    ship = (b.get("ShipToAddress") or "").strip() or (b.get("BillToAddress") or "").strip()
    existing = shared_col("green_digital_clients").find_one({"Id": cust_id}, {"_id": 0, "ClientName": 1, "Name": 1, "PreviousNames": 1}) or {}
    update_set = {
        "ClientName":    name,
        "Name":          name,
        "Address":       b.get("Address", b.get("BillToAddress", "")),
        "BillToAddress": b.get("BillToAddress", ""),
        "ShipToAddress": ship,
        "State":         b.get("State", ""),
        "StateCode":     b.get("StateCode", ""),
        "Mobile":        b.get("Mobile", ""),
        "GSTNo":         b.get("GSTNo", ""),
        "Email":         b.get("Email", ""),
        "CustomerType":  b.get("CustomerType", ""),
    }
    # If the name actually changed, remember the old name so "Update
    # Everywhere" can still find historical sales/invoices/quotations that
    # were saved under that old spelling, even after this rename.
    old_name = (existing.get("ClientName") or existing.get("Name") or "").strip()
    if old_name and old_name.lower() != name.lower():
        prev = existing.get("PreviousNames") or []
        if old_name not in prev:
            prev.append(old_name)
        update_set["PreviousNames"] = prev
    result = shared_col("green_digital_clients").update_one({"Id": cust_id}, {"$set": update_set})
    if result.matched_count == 0:
        return err("Customer not found", 404)
    return ok({"success": True})

@app.post("/api/customers/{cust_id}/update-everywhere")
@app.post("/api/billing/customers/{cust_id}/update-everywhere")
async def customer_update_everywhere(cust_id: int, request: Request):
    """
    Push this customer's CURRENT details (name, GST, state, mobile, email,
    address) onto every existing sales record, invoice and quotation that
    was saved under this customer's current name OR any of its previously
    known names (tracked automatically whenever the customer is renamed).
    This does not change any totals/amounts — only the customer-identifying
    text fields that were copied onto those records at the time they were
    created.

    Optional body: {"oldName": "..."} — manually add an old spelling to
    search for, useful if a rename happened before this tracking existed.
    """
    if not await ensure_db(): return err("Database not connected", 503)
    cust = shared_col("green_digital_clients").find_one({"Id": cust_id}, {"_id": 0})
    if not cust:
        return err("Customer not found", 404)

    try:
        body = await request.json()
    except Exception:
        body = {}
    manual_old_name = (body.get("oldName") or "").strip() if isinstance(body, dict) else ""

    current_name = (cust.get("ClientName") or cust.get("Name") or "").strip()
    if not current_name:
        return err("This customer has no name on record", 400)
    prev_names = cust.get("PreviousNames") or []
    all_names = list({current_name, *prev_names})
    if manual_old_name:
        all_names.append(manual_old_name)
        # Persist it for next time too, so this only needs to be done once.
        if manual_old_name not in prev_names:
            shared_col("green_digital_clients").update_one(
                {"Id": cust_id},
                {"$addToSet": {"PreviousNames": manual_old_name}}
            )

    name_regex = {"$in": [re.compile(f"^{re.escape(n)}$", re.IGNORECASE) for n in all_names]}

    # ── Sales records: only the plain Customer text field exists here ──
    sales_result = col("sales_records").update_many(
        {"Customer": name_regex},
        {"$set": {"Customer": current_name}}
    )

    # ── Invoices: name + GST + state code + address/mobile/email ──
    inv_update = {
        "CustomerName":       current_name,
        "CustomerGST":        cust.get("GSTNo", ""),
        "CustomerStateCode":  cust.get("StateCode", ""),
        "CustomerAddress":    cust.get("BillToAddress", ""),
        "CustomerState":      cust.get("State", ""),
        "CustomerMobile":     cust.get("Mobile", ""),
        "CustomerEmail":      cust.get("Email", ""),
    }
    inv_result = col("sales_invoices").update_many(
        {"$or": [{"CustomerId": cust_id}, {"CustomerName": name_regex}]},
        {"$set": inv_update}
    )

    # ── Quotations: same fields as invoices ──
    quot_result = col("quotations").update_many(
        {"$or": [{"CustomerId": cust_id}, {"CustomerName": name_regex}]},
        {"$set": inv_update}
    )

    return ok({
        "success": True,
        "sales": sales_result.modified_count,
        "invoices": inv_result.modified_count,
        "quotations": quot_result.modified_count,
    })

@app.delete("/api/billing/customers/{cust_id}")
async def billing_delete_customer(cust_id: int, user: Optional[str] = Query(None), scope: Optional[str] = Query(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    # IMPORTANT: find_one with an inclusion projection like {"createdBy": 1}
    # returns an EMPTY DICT {} (not None) when the document exists but has
    # no createdBy field — and {} is falsy in Python, so `if not record`
    # incorrectly treated "found, but no createdBy" the same as "not found".
    # Fix: check existence explicitly with `record is None`, and rely on
    # full deletion only after we've confirmed it actually exists.
    exists = shared_col("green_digital_clients").count_documents({"Id": cust_id}, limit=1) > 0
    if not exists:
        return err("Customer not found", 404)
    record = shared_col("green_digital_clients").find_one({"Id": cust_id}, {"_id": 0, "createdBy": 1}) or {}
    # Scope check: scoped users can only delete their own records
    if scope == "own" and user:
        record_owner = record.get("createdBy", "")
        if record_owner and record_owner != user:
            return err("Access denied — you can only delete customers you created.", 403)
    shared_col("green_digital_clients").delete_one({"Id": cust_id})
    return ok({"success": True})

# ─────────────────────────────────────────────
#  BILLING — PRODUCTS
# ─────────────────────────────────────────────
@app.get("/api/billing/products/nextcode")
async def billing_nextcode():
    return JSONResponse(content={"code": next_product_code()})

@app.get("/api/billing/products")
async def billing_get_products(q: Optional[str] = Query(None)):
    if q:
        query = {"$or": [{"Name": {"$regex": q, "$options": "i"}}, {"Code": {"$regex": q, "$options": "i"}}]}
    else:
        query = {}
    rows = list(col("products").find(query, {"_id": 0}).sort("Code", ASCENDING))
    return JSONResponse(content=rows)

@app.post("/api/billing/products")
async def billing_post_product(request: Request):
    b = await request.json()
    name = (b.get("Name") or "").strip()
    if not name: return err("Name required")
    code = (b.get("Code") or "").strip() or next_product_code()
    new_id = next_id("products")
    col("products").insert_one({
        "Id": new_id, "Code": code, "Name": name,
        "createdBy": (b.get("createdBy") or "").strip(),
        "PrintName": b.get("PrintName",""), "HSN": b.get("HSN",""),
        "Category": b.get("Category",""), "Unit": b.get("Unit","Nos"),
        "GSTRate": to_float(b.get("GSTRate"), 18.0),
    })
    return ok({"success": True, "id": new_id, "code": code})

@app.get("/api/billing/products/{prod_id}")
async def billing_get_product(prod_id: int):
    r = col("products").find_one({"Id": prod_id}, {"_id": 0})
    if not r: return err("Not found", 404)
    return JSONResponse(content=r)

@app.put("/api/billing/products/{prod_id}")
async def billing_put_product(prod_id: int, request: Request):
    b = await request.json()
    col("products").update_one({"Id": prod_id}, {"$set": {
        "Code": b.get("Code",""), "Name": b.get("Name",""),
        "PrintName": b.get("PrintName",""), "HSN": b.get("HSN",""),
        "Category": b.get("Category",""), "Unit": b.get("Unit","Nos"),
        "GSTRate": to_float(b.get("GSTRate"), 18.0),
    }})
    return ok({"success": True})

@app.delete("/api/billing/products/{prod_id}")
async def billing_delete_product(prod_id: int, user: Optional[str] = Query(None), scope: Optional[str] = Query(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    exists = col("products").count_documents({"Id": prod_id}, limit=1) > 0
    if not exists:
        return err("Product not found", 404)
    record = col("products").find_one({"Id": prod_id}, {"_id": 0, "createdBy": 1}) or {}
    # Scope check: scoped users can only delete their own records
    if scope == "own" and user:
        record_owner = record.get("createdBy", "")
        if record_owner and record_owner != user:
            return err("Access denied — you can only delete products you created.", 403)
    col("products").delete_one({"Id": prod_id})
    return ok({"success": True})

# ─────────────────────────────────────────────
#  BILLING — INVOICE SEQUENCES
# ─────────────────────────────────────────────
# ── Invoice numbering: cancel instead of delete ─────────────────────────────────────────────────────
# An issued invoice keeps its number for ever. Mistakes are fixed by CANCELLING (number kept, record kept,
# marked CANCELLED, left out of totals and reports) rather than deleting, so the series never has silent gaps.
def _inv_prefix(inv_no):
    m = re.match(r'^([A-Za-z]+)\d', (inv_no or '').strip())
    return m.group(1) if m else ''

def _inv_series_regex(inv_no):
    p = _inv_prefix(inv_no)
    return (r'^%s\d' % re.escape(p)) if p else r'^\d'

def _inv_is_nongst(inv_no):
    return _inv_prefix(inv_no).upper() in ("RN", "RUN", "GDN")

async def _caller_username(request: Request):
    try:
        tok = _bearer_token(request)
        u = _db["green_digital_users"].find_one({"session_token": tok}, {"_id": 0}) if tok else None
        return (u or {}).get("username", "") or ""
    except Exception:
        return ""

@app.post("/api/billing/invoices/mark-issued")
async def billing_mark_invoice_issued(invno: str = Query("")):
    """Called when an invoice is printed / turned into a PDF: from then on it can only be cancelled, not deleted."""
    if not await ensure_db(): return err("Database not connected", 503)
    if not invno: return err("invno required")
    inv = col("sales_invoices").find_one({"InvoiceNo": invno}, {"_id": 0, "Id": 1, "Status": 1, "Issued": 1}, sort=[("Id", DESCENDING)])
    if not inv: return ok({"success": True, "found": False})
    if inv.get("Status") != "Cancelled" and not inv.get("Issued"):
        col("sales_invoices").update_one({"Id": inv["Id"]}, {"$set": {"Issued": True, "IssuedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}})
    return ok({"success": True, "found": True})

@app.get("/api/billing/invoices/gaps")
async def billing_invoice_gaps(fy: str = Query("")):
    """Numbering check: for each series (GD01.. / GDN01.. / R01.. ...) in the financial year, which numbers are missing."""
    if not await ensure_db(): return err("Database not connected", 503)
    if not fy: fy = current_fy()
    fy_from, fy_to = fy_range(fy)
    rows = list(col("sales_invoices").find({"$or": [{"FY": fy}, {"$and": [{"FY": None}, {"InvoiceDate": {"$gte": fy_from, "$lte": fy_to}}]}]}, {"_id": 0, "InvoiceNo": 1, "Status": 1}))
    series = {}
    for r in rows:
        m = re.match(r'^([A-Za-z]+)(\d+)$', (r.get("InvoiceNo") or "").strip())
        if not m: continue
        d = series.setdefault(m.group(1), {"numbers": set(), "cancelled": set()})
        n = int(m.group(2)); d["numbers"].add(n)
        if r.get("Status") == "Cancelled": d["cancelled"].add(n)
    out = []
    for pfx, d in sorted(series.items()):
        mx = max(d["numbers"])
        out.append({"prefix": pfx, "count": len(d["numbers"]), "max": mx,
                    "missing": ["%s%02d" % (pfx, n) for n in range(1, mx + 1) if n not in d["numbers"]],
                    "cancelled": ["%s%02d" % (pfx, n) for n in sorted(d["cancelled"])]})
    return JSONResponse(content={"fy": fy, "series": out})

@app.post("/api/billing/invoices/{inv_id}/cancel")
async def billing_cancel_invoice(inv_id: int, request: Request):
    """Cancel an invoice (admin only, reason required). The number and the record are kept."""
    _g = await admin_guard(request)
    if _g: return _g
    b = await request.json()
    reason = (b.get("reason") or "").strip()
    if len(reason) < 3: return err("Please give a reason for cancelling the invoice.", 400)
    inv = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0})
    if not inv: return err("Invoice not found", 404)
    if inv.get("Status") == "Cancelled": return err("This invoice is already cancelled.", 409)
    inv_no = inv.get("InvoiceNo", "")
    linked = [r.get("SNo") for r in col("sales_records").find({"InvoiceNo": inv_no}, {"_id": 0, "SNo": 1})]
    col("sales_invoices").update_one({"Id": inv_id}, {"$set": {
        "Status": "Cancelled", "CancelReason": reason, "CancelledBy": await _caller_username(request),
        "CancelledAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "CancelledSalesSNo": linked}})
    # the sale it was made for can be invoiced again (with a NEW number)
    col("sales_records").update_many({"InvoiceNo": inv_no}, {"$set": {"InvoiceNo": ""}})
    return ok({"success": True, "invoiceNo": inv_no, "unlinkedSales": linked})

@app.get("/api/billing/invoices/peek")
async def billing_invoice_peek(type: str = Query("GST"), fy: str = Query("")):
    if not fy: fy = current_fy()
    return JSONResponse(content={"invoiceNo": next_invoice_no(type, fy)})

@app.get("/api/billing/invoices/next")
async def billing_invoice_next(type: str = Query("GST"), fy: str = Query("")):
    if not fy: fy = current_fy()
    return JSONResponse(content={"invoiceNo": next_invoice_no(type, fy)})

@app.post("/api/billing/invoices/resetsequence")
async def billing_reset_sequence(type: str = Query("GST")):
    return ok({"success": True, "type": type})

# ─────────────────────────────────────────────
#  BILLING — INVOICES
# ─────────────────────────────────────────────
@app.get("/api/billing/invoices/byno")
async def billing_invoice_byno(invno: str = Query(""), fy: str = Query("")):
    if not invno: return err("invno required")
    query = {"InvoiceNo": invno}
    if fy:
        fy_from, fy_to = fy_range(fy)
        query["InvoiceDate"] = {"$gte": fy_from, "$lte": fy_to}
    inv = col("sales_invoices").find_one(query, {"_id": 0}, sort=[("Id", DESCENDING)])
    if not inv: return err("Not found", 404)
    inv_id = inv.get("Id")
    items = list(col("sales_items").find({"InvoiceId": inv_id}, {"_id": 0}).sort("SNo", ASCENDING))
    # Fetch customer details
    cust = {}
    if inv.get("CustomerId"):
        c = shared_col("green_digital_clients").find_one({"Id": inv["CustomerId"]}, {"_id": 0})
        if c:
            cust = {"CustomerAddress": c.get("BillToAddress",""), "CustomerState": c.get("State",""),
                    "CustomerStateCode": c.get("StateCode",""), "CustomerMobile": c.get("Mobile",""),
                    "CustomerGST": c.get("GSTNo",""), "CustomerEmail": c.get("Email","")}
    # Keep InvoiceDate as the raw YYYY-MM-DD stored in MongoDB. Previously
    # this was reformatted to DD-MM-YYYY, which broke the edit form's date
    # input (which requires YYYY-MM-DD) and is unreliable for fd()'s
    # new Date(d) parsing on the frontend (DD-MM-YYYY is ambiguous/invalid
    # in JS Date parsing across browsers).
    return JSONResponse(content={**inv, **cust, "Items": items})

@app.get("/api/billing/invoices")
async def billing_get_invoices(
    page: int = Query(1), pageSize: int = Query(50),
    fr: Optional[str] = Query(None, alias="from"), to: Optional[str] = Query(None),
    type: Optional[str] = Query(None), q: Optional[str] = Query(None),
    scope: Optional[str] = Query(None), user: Optional[str] = Query(None),
    includeCancelled: int = Query(0)
):
    pageSize = max(1, min(pageSize, 500))
    query = {}
    if fr or to:
        query["InvoiceDate"] = {}
        if fr: query["InvoiceDate"]["$gte"] = fr
        if to: query["InvoiceDate"]["$lte"] = to
    if type == "GST":    query["BillingType"] = {"$in": ["GST", "IGST"]}
    if type == "NONGST": query["BillingType"] = "NON-GST"
    if q:
        # Also search by product name — find invoice IDs that have matching items
        matching_item_inv_ids = [
            r["InvoiceId"] for r in col("sales_items").find(
                {"ProductName": {"$regex": q, "$options": "i"}}, {"InvoiceId": 1, "_id": 0}
            )
        ]
        query["$or"] = [
            {"CustomerName": {"$regex": q, "$options": "i"}},
            {"InvoiceNo":    {"$regex": q, "$options": "i"}},
            {"Id":           {"$in": matching_item_inv_ids}},
        ]
    if scope == "own" and user: query["createdBy"] = user
    if not includeCancelled: query["Status"] = {"$ne": "Cancelled"}   # cancelled invoices stay out of totals and reports
    total = col("sales_invoices").count_documents(query)
    skip  = (page - 1) * pageSize
    rows  = list(col("sales_invoices").find(query, {"_id": 0, "Id":1,"InvoiceNo":1,"InvoiceDate":1,"CustomerName":1,"BillingType":1,"SubTotal":1,"CGST":1,"SGST":1,"IGST":1,"TotalAmount":1,"Counter":1,"PaymentTerms":1,"createdBy":1,"CustomerGST":1,"PlaceOfSupply":1,"Status":1,"CancelReason":1,"CancelledAt":1,"CancelledBy":1,"Issued":1})
                .sort([("InvoiceDate", DESCENDING), ("Id", DESCENDING)]).skip(skip).limit(pageSize))
    
    # Build product HSN lookup map (Name/PrintName → HSN)
    hsn_lookup = {}
    try:
        for prod in col("products").find({}, {"_id": 0, "Name": 1, "PrintName": 1, "HSN": 1}):
            hsn = prod.get("HSN", "")
            if prod.get("Name"):  hsn_lookup[prod["Name"].strip().lower()] = hsn
            if prod.get("PrintName"): hsn_lookup[prod["PrintName"].strip().lower()] = hsn
    except Exception:
        pass

    # Fetch HSN and Qty from sales_items for each invoice
    processed_rows = []
    for r in rows:
        row_data = dict(r)
        row_data["HSN"] = ""
        row_data["Quantity"] = 0

        # Get first item from sales_items collection
        item = col("sales_items").find_one({"InvoiceId": r.get("Id")}, {"_id": 0, "HSN": 1, "Qty": 1, "ProductName": 1, "Description": 1})
        if item:
            hsn = (item.get("HSN") or "").strip()
            # If HSN empty in item, look up from product catalog
            if not hsn:
                pname = (item.get("ProductName") or item.get("Description") or "").strip().lower()
                hsn = hsn_lookup.get(pname, "")
            row_data["HSN"] = hsn
            row_data["Quantity"] = to_float(item.get("Qty", 0), 0)

        processed_rows.append(row_data)
    
    return JSONResponse(content={"data": processed_rows, "total": total, "page": page, "pageSize": pageSize})

@app.get("/api/billing/invoices/{inv_id}")
async def billing_get_invoice(inv_id: int):
    r = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0})
    if not r: return err("Invoice not found", 404)
    # Include line items and customer details in the same response so the
    # frontend doesn't need a second round-trip (to /byno) just to get them —
    # that extra call was adding a real, avoidable delay every time an
    # invoice was opened for editing.
    items = list(col("sales_items").find({"InvoiceId": inv_id}, {"_id": 0}).sort("SNo", ASCENDING))
    cust = {}
    if r.get("CustomerId"):
        c = shared_col("green_digital_clients").find_one({"Id": r["CustomerId"]}, {"_id": 0})
        if c:
            cust = {"CustomerAddress": c.get("BillToAddress",""), "CustomerState": c.get("State",""),
                    "CustomerStateCode": c.get("StateCode",""), "CustomerMobile": c.get("Mobile",""),
                    "CustomerGST": c.get("GSTNo",""), "CustomerEmail": c.get("Email","")}
    return JSONResponse(content={**r, **cust, "Items": items})

@app.post("/api/billing/invoices")
async def billing_post_invoice(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    inv_no = (b.get("InvoiceNo") or "").strip()
    if not inv_no: return err("InvoiceNo required")
    raw_date = b.get("InvoiceDate", "")
    try:
        inv_date = datetime.strptime(raw_date[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except:
        inv_date = datetime.now().strftime("%Y-%m-%d")
    fy = fy_from_date(inv_date)
    _f0, _f1 = fy_range(fy)
    if col("sales_invoices").find_one({"InvoiceNo": inv_no, "$or": [{"FY": fy}, {"$and": [{"FY": None}, {"InvoiceDate": {"$gte": _f0, "$lte": _f1}}]}]}, {"_id": 0, "Id": 1}):
        _nx = next_invoice_no("NonGST" if _inv_is_nongst(inv_no) else "GST", fy)
        return err(f"Invoice number {inv_no} is already used by another invoice (someone may have just saved it). The next free number is {_nx} - refresh the number and save again.", 409)
    new_id = next_id("sales_invoices")
    doc = {
        "Id": new_id, "Branch": "HO", "InvoiceNo": inv_no, "InvoiceDate": inv_date,
        "createdBy": (b.get("createdBy") or "").strip(),
        "CustomerId": to_int(b.get("CustomerId"), 0),
        "CustomerName": b.get("CustomerName",""), "BillingType": b.get("BillingType",""),
        "CustomerGST": b.get("CustomerGST",""),
        "PlaceOfSupply": b.get("PlaceOfSupply",""), "PlaceOfSupplyCode": b.get("PlaceOfSupplyCode",""),
        "SubTotal": to_float(b.get("SubTotal"),0), "CGST": to_float(b.get("CGST"),0),
        "SGST": to_float(b.get("SGST"),0), "IGST": to_float(b.get("IGST"),0),
        "TotalAmount": to_float(b.get("TotalAmount"),0),
        "Counter": b.get("Counter",""), "PaymentTerms": b.get("PaymentTerms",""), "FY": fy
    }
    col("sales_invoices").insert_one(doc)
    sno = 1
    for item in (b.get("Items") or []):
        if not item: continue
        qty = to_float(item.get("Qty"),0); rate = to_float(item.get("Rate"),0)
        tv  = to_float(item.get("TaxableValue"), qty*rate if qty and rate else 0)
        it  = to_float(item.get("Total"), tv)
        if not item.get("ProductName") and not tv: continue
        col("sales_items").insert_one({
            "InvoiceId": new_id, "SNo": sno,
            "ProductName": item.get("ProductName",""), "HSN": item.get("HSN",""),
            "Qty": qty, "Rate": rate, "TaxableValue": tv,
            "GSTRate": to_float(item.get("GSTRate"),0), "Total": it,
            "SizeNotes": item.get("SizeNotes","")
        })
        sno += 1
    return ok({"success": True, "id": new_id, "invoiceNo": inv_no})


@app.patch("/api/billing/invoices/{inv_id}/refresh-customer")
async def refresh_invoice_customer(inv_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    exists = col("sales_invoices").count_documents({"Id": inv_id}, limit=1) > 0
    if not exists: return err("Invoice not found", 404)
    inv = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0, "CustomerId": 1}) or {}
    cust_id = inv.get("CustomerId")
    if not cust_id: return err("No customer linked to this invoice", 400)
    cust = shared_col("green_digital_clients").find_one({"Id": cust_id}, {"_id": 0})
    if not cust: return err("Customer not found", 404)
    update = {
        "CustomerName":    cust.get("Name") or cust.get("ClientName") or "",
        "CustomerGST":     cust.get("GSTNo") or cust.get("GSTIN") or "",
        "CustomerMobile":  cust.get("Mobile") or cust.get("Phone") or "",
        "CustomerEmail":   cust.get("Email") or "",
        "BillToAddress":   cust.get("BillToAddress") or cust.get("Address") or "",
        "ShipToAddress":   cust.get("ShipToAddress") or cust.get("BillToAddress") or cust.get("Address") or "",
        "PlaceOfSupply":   cust.get("State") or "",
    }
    col("sales_invoices").update_one({"Id": inv_id}, {"$set": update})
    return ok({"success": True, "updated": update})

@app.patch("/api/quotations/{qid}/refresh-customer")
async def refresh_quotation_customer(qid: str):
    if not await ensure_db(): return err("Database not connected", 503)
    try: qid_int = int(qid)
    except: qid_int = None
    query = {"Id": qid_int} if qid_int else {"_id": __import__("bson").ObjectId(qid)}
    exists = col("quotations").count_documents(query, limit=1) > 0
    if not exists: return err("Quotation not found", 404)
    quot = col("quotations").find_one(query, {"_id": 0, "CustomerId": 1, "CustomerName": 1}) or {}
    cust_id = quot.get("CustomerId")
    cust = None
    if cust_id:
        cust = shared_col("green_digital_clients").find_one({"Id": cust_id}, {"_id": 0})
    if not cust:
        # Quotations created by typing a customer name (e.g. from the mobile
        # "New Quote" form) never get a CustomerId — fall back to a
        # case-insensitive name match so Update still works for them.
        cust_name = (quot.get("CustomerName") or "").strip()
        if not cust_name: return err("No customer linked to this quotation", 400)
        import re as _re
        cust = shared_col("green_digital_clients").find_one(
            {"Name": {"$regex": f"^{_re.escape(cust_name)}$", "$options": "i"}},
            {"_id": 0}
        )
        if not cust:
            return err("No matching customer record found for '" + cust_name + "'", 404)
    update = {
        "CustomerName":   cust.get("Name") or cust.get("ClientName") or "",
        "CustomerGST":    cust.get("GSTNo") or cust.get("GSTIN") or "",
        "CustomerMobile": cust.get("Mobile") or cust.get("Phone") or "",
        "CustomerEmail":  cust.get("Email") or "",
        "BillToAddress":  cust.get("BillToAddress") or cust.get("Address") or "",
        "ShipToAddress":  cust.get("ShipToAddress") or cust.get("BillToAddress") or cust.get("Address") or "",
        "PlaceOfSupply":  cust.get("State") or "",
    }
    col("quotations").update_one(query, {"$set": update})
    return ok({"success": True, "updated": update})

# Alias with /billing/ prefix so mobile can use a consistent URL pattern
@app.patch("/api/billing/quotations/{qid}/refresh-customer")
async def billing_refresh_quotation_customer(qid: str):
    return await refresh_quotation_customer(qid)

# Alias without /billing/ prefix for invoice (was missing — needed for mobile Update button)
@app.patch("/api/invoices/{inv_id}/refresh-customer")
async def refresh_invoice_customer_alias(inv_id: int):
    return await refresh_invoice_customer(inv_id)

async def billing_put_invoice(inv_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    _cur = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0, "Status": 1})
    if _cur and _cur.get("Status") == "Cancelled": return err("This invoice is cancelled and cannot be edited.", 409)
    b = await request.json()
    raw_date = b.get("InvoiceDate","")
    try: inv_date = datetime.strptime(raw_date[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except: inv_date = datetime.now().strftime("%Y-%m-%d")
    col("sales_invoices").update_one({"Id": inv_id}, {"$set": {
        "InvoiceDate": inv_date, "FY": fy_from_date(inv_date),
        "CustomerId": to_int(b.get("CustomerId"),0),
        "CustomerName": b.get("CustomerName",""), "BillingType": b.get("BillingType",""),
        "CustomerGST": b.get("CustomerGST",""),
        "PlaceOfSupply": b.get("PlaceOfSupply",""), "PlaceOfSupplyCode": b.get("PlaceOfSupplyCode",""),
        "SubTotal": to_float(b.get("SubTotal"),0), "CGST": to_float(b.get("CGST"),0),
        "SGST": to_float(b.get("SGST"),0), "IGST": to_float(b.get("IGST"),0),
        "TotalAmount": to_float(b.get("TotalAmount"),0),
        "Counter": b.get("Counter",""), "PaymentTerms": b.get("PaymentTerms",""),
    }})
    col("sales_items").delete_many({"InvoiceId": inv_id})
    sno = 1
    for item in (b.get("Items") or []):
        if not item: continue
        qty = to_float(item.get("Qty"),0); rate = to_float(item.get("Rate"),0)
        tv  = to_float(item.get("TaxableValue"), qty*rate if qty and rate else 0)
        it  = to_float(item.get("Total"), tv)
        if not item.get("ProductName") and not tv: continue
        col("sales_items").insert_one({
            "InvoiceId": inv_id, "SNo": sno,
            "ProductName": item.get("ProductName",""), "HSN": item.get("HSN",""),
            "Qty": qty, "Rate": rate, "TaxableValue": tv,
            "GSTRate": to_float(item.get("GSTRate"),0), "Total": it,
            "SizeNotes": item.get("SizeNotes","")
        })
        sno += 1
    inv_no = col("sales_invoices").find_one({"Id": inv_id}, {"InvoiceNo": 1})
    return ok({"success": True, "id": inv_id, "invoiceNo": inv_no.get("InvoiceNo","") if inv_no else ""})

@app.delete("/api/billing/invoices/{inv_id}")
async def billing_delete_invoice(inv_id: int):
    """Delete is only for a mistake that never left the building: the most recent invoice of its series, never printed
    or shared. Anything else is cancelled instead (see /cancel), which keeps the number."""
    if not await ensure_db(): return err("Database not connected", 503)
    inv = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0, "InvoiceNo": 1, "Status": 1, "Issued": 1})
    if not inv: return err("Invoice not found", 404)
    inv_no = inv.get("InvoiceNo", "")
    if inv.get("Status") == "Cancelled":
        return err("A cancelled invoice is kept for the record and cannot be deleted.", 409)
    if inv.get("Issued"):
        return err(f"Invoice {inv_no} has already been printed or shared, so it cannot be deleted. Use Cancel instead - the number is kept and the invoice is marked CANCELLED.", 403)
    latest = col("sales_invoices").find_one({"InvoiceNo": {"$regex": _inv_series_regex(inv_no)}}, sort=[("Id", DESCENDING)])
    if not latest or latest.get("Id") != inv_id:
        return err("Only the most recent invoice in this series can be deleted. Use Cancel for an older one.", 403)
    col("sales_items").delete_many({"InvoiceId": inv_id})
    col("sales_invoices").delete_one({"Id": inv_id})
    col("sales_records").update_many({"InvoiceNo": inv_no}, {"$set": {"InvoiceNo": ""}})
    return ok({"success": True, "invoiceNo": inv_no})

# ─────────────────────────────────────────────
#  BILLING — QUOTATIONS
# ─────────────────────────────────────────────
@app.get("/api/billing/quotations/peek")
async def billing_quotation_peek(type: str = Query("GST"), fy: str = Query("")):
    if not fy: fy = current_fy()
    return JSONResponse(content={"quotationNo": next_quotation_no(type, fy)})

@app.get("/api/billing/quotations/next")
async def billing_quotation_next(type: str = Query("GST"), fy: str = Query("")):
    if not fy: fy = current_fy()
    return JSONResponse(content={"quotationNo": next_quotation_no(type, fy)})

@app.get("/api/billing/quotations/byno")
async def billing_quotation_byno(qno: str = Query("")):
    if not qno: return err("qno required")
    q = col("quotations").find_one({"QuotationNo": qno}, {"_id": 0})
    if not q: return err("Not found", 404)
    q_id = q.get("Id")
    items = list(col("quotation_items").find({"QuotationId": q_id}, {"_id": 0}).sort("SNo", ASCENDING))
    # Keep QuotationDate/ValidTill as raw YYYY-MM-DD from MongoDB. Previously
    # reformatted to DD-MM-YYYY, which broke the edit form's date input
    # (requires YYYY-MM-DD) and is unreliable for fd()'s new Date(d) parsing
    # on the frontend.
    return JSONResponse(content={**q, "Items": items})

@app.get("/api/billing/quotations")
async def billing_get_quotations(
    page: int = Query(1), pageSize: int = Query(50),
    fr: Optional[str] = Query(None, alias="from"), to: Optional[str] = Query(None),
    type: Optional[str] = Query(None), q: Optional[str] = Query(None),
    scope: Optional[str] = Query(None), user: Optional[str] = Query(None),
    mobile: Optional[str] = Query(None)
):
    pageSize = max(1, min(pageSize, 500))
    query = {}
    if fr or to:
        query["QuotationDate"] = {}
        if fr: query["QuotationDate"]["$gte"] = fr
        if to: query["QuotationDate"]["$lte"] = to
    if type == "GST":    query["BillingType"] = {"$in": ["GST","IGST"]}
    if type == "NONGST": query["BillingType"] = "NON-GST"
    if q:
        # Also search by product name — find quotation IDs that have matching items
        matching_item_quot_ids = [
            r["QuotationId"] for r in col("quotation_items").find(
                {"ProductName": {"$regex": q, "$options": "i"}}, {"QuotationId": 1, "_id": 0}
            )
        ]
        query["$or"] = [
            {"CustomerName":  {"$regex": q, "$options": "i"}},
            {"QuotationNo":   {"$regex": q, "$options": "i"}},
            {"Id":            {"$in": matching_item_quot_ids}},
        ]
    if scope == "own" and user: query["createdBy"] = user
    if mobile == "true": query["mobile_visible"] = True
    total = col("quotations").count_documents(query)
    skip  = (page - 1) * pageSize
    rows  = list(col("quotations").find(query, {"_id": 0})
                .sort([("QuotationDate", DESCENDING), ("Id", DESCENDING)]).skip(skip).limit(pageSize))
    return JSONResponse(content={"data": rows, "total": total, "page": page, "pageSize": pageSize})

@app.get("/api/billing/quotations/{quot_id}")
async def billing_get_quotation(quot_id: int):
    q = col("quotations").find_one({"Id": quot_id}, {"_id": 0})
    if not q: return err("Quotation not found", 404)
    items = list(col("quotation_items").find({"QuotationId": quot_id}, {"_id": 0}).sort("SNo", ASCENDING))
    return JSONResponse(content={**q, "Items": items})

@app.post("/api/billing/quotations")
async def billing_post_quotation(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    q_no = (b.get("QuotationNo") or "").strip()
    if not q_no: return err("QuotationNo required")
    try: q_date = datetime.strptime(b.get("QuotationDate","")[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except: q_date = datetime.now().strftime("%Y-%m-%d")
    try: vt = datetime.strptime(b.get("ValidTill","")[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except: vt = q_date
    new_id = next_id("quotations")
    doc = {
        "Id": new_id, "QuotationNo": q_no, "QuotationDate": q_date,
        "createdBy": (b.get("createdBy") or "").strip(),
        "CustomerId": to_int(b.get("CustomerId"),0),
        "CustomerName": b.get("CustomerName",""), "BillingType": b.get("BillingType",""),
        "PlaceOfSupply": b.get("PlaceOfSupply",""), "PlaceOfSupplyCode": b.get("PlaceOfSupplyCode",""),
        "SubTotal": to_float(b.get("SubTotal"),0), "CGST": to_float(b.get("CGST"),0),
        "SGST": to_float(b.get("SGST"),0), "IGST": to_float(b.get("IGST"),0),
        "TotalAmount": to_float(b.get("TotalAmount"),0),
        "PaymentTerms": b.get("PaymentTerms",""), "ValidTill": vt
    }
    col("quotations").insert_one(doc)
    sno = 1
    for item in (b.get("Items") or []):
        if not item: continue
        qty = to_float(item.get("Qty"),0); rate = to_float(item.get("Rate"),0)
        tv  = to_float(item.get("TaxableValue"), qty*rate if qty and rate else 0)
        it  = to_float(item.get("Total"), tv)
        if not item.get("ProductName") and not tv: continue
        col("quotation_items").insert_one({
            "QuotationId": new_id, "SNo": sno,
            "ProductName": item.get("ProductName",""), "HSN": item.get("HSN",""),
            "Qty": qty, "Rate": rate, "TaxableValue": tv,
            "GSTRate": to_float(item.get("GSTRate"),0), "Total": it,
            "SizeNotes": item.get("SizeNotes","")
        })
        sno += 1
    return ok({"success": True, "id": new_id, "quotationNo": q_no})


@app.put("/api/billing/quotations/{quot_id}")
async def billing_put_quotation(quot_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    q_no = (b.get("QuotationNo") or "").strip()
    if not q_no: return err("QuotationNo required")
    try: q_date = datetime.strptime(b.get("QuotationDate","")[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except: q_date = datetime.now().strftime("%Y-%m-%d")
    try: vt = datetime.strptime(b.get("ValidTill","")[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except: vt = q_date
    update_doc = {
        "QuotationNo": q_no, "QuotationDate": q_date,
        "CustomerId": to_int(b.get("CustomerId"),0),
        "CustomerName": b.get("CustomerName",""), "BillingType": b.get("BillingType",""),
        "PlaceOfSupply": b.get("PlaceOfSupply",""), "PlaceOfSupplyCode": b.get("PlaceOfSupplyCode",""),
        "SubTotal": to_float(b.get("SubTotal"),0), "CGST": to_float(b.get("CGST"),0),
        "SGST": to_float(b.get("SGST"),0), "IGST": to_float(b.get("IGST"),0),
        "TotalAmount": to_float(b.get("TotalAmount"),0),
        "PaymentTerms": b.get("PaymentTerms",""), "ValidTill": vt
    }
    col("quotations").update_one({"Id": quot_id}, {"$set": update_doc})
    # Replace items
    col("quotation_items").delete_many({"QuotationId": quot_id})
    sno = 1
    for item in (b.get("Items") or []):
        if not item: continue
        qty = to_float(item.get("Qty"),0); rate = to_float(item.get("Rate"),0)
        tv  = to_float(item.get("TaxableValue"), qty*rate if qty and rate else 0)
        it  = to_float(item.get("Total"), tv)
        if not item.get("ProductName") and not tv: continue
        col("quotation_items").insert_one({
            "QuotationId": quot_id, "SNo": sno,
            "ProductName": item.get("ProductName",""), "HSN": item.get("HSN",""),
            "Qty": qty, "Rate": rate, "TaxableValue": tv,
            "GSTRate": to_float(item.get("GSTRate"),0), "Total": it,
            "SizeNotes": item.get("SizeNotes","")
        })
        sno += 1
    return ok({"success": True, "quotationNo": q_no})

@app.delete("/api/billing/quotations/{quot_id}")
async def billing_delete_quotation(quot_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    # Find this quotation first to determine its series (GST vs Non-GST)
    quot_exists = col("quotations").count_documents({"Id": quot_id}, limit=1) > 0
    if not quot_exists:
        return err("Quotation not found", 404)
    this_quot = col("quotations").find_one({"Id": quot_id}, {"QuotationNo": 1}) or {}
    qno = this_quot.get("QuotationNo", "")
    # Find the latest quotation in the SAME series
    if qno.startswith("QN"):
        latest = col("quotations").find_one({"QuotationNo": {"$regex": r"^QN"}}, sort=[("Id", DESCENDING)])
    else:
        latest = col("quotations").find_one({"QuotationNo": {"$regex": r"^Q\d"}}, sort=[("Id", DESCENDING)])
    if not latest or latest.get("Id") != quot_id:
        return err("Only the most recent quotation in this series can be deleted.", 403)
    col("quotation_items").delete_many({"QuotationId": quot_id})
    col("quotations").delete_one({"Id": quot_id})
    return ok({"success": True})

# ─────────────────────────────────────────────
#  BILLING — REPORTS
# ─────────────────────────────────────────────
@app.get("/api/billing/reports/sales")
async def billing_reports_sales(
    fr: Optional[str] = Query(None, alias="from"), to: Optional[str] = Query(None),
    type: Optional[str] = Query(None)
):
    query = {}
    if fr or to:
        query["InvoiceDate"] = {}
        if fr: query["InvoiceDate"]["$gte"] = fr
        if to: query["InvoiceDate"]["$lte"] = to
    if type == "GST":    query["BillingType"] = {"$in": ["GST","IGST"]}
    if type == "NONGST": query["BillingType"] = "NON-GST"
    query["Status"] = {"$ne": "Cancelled"}
    rows = list(col("sales_invoices").find(query, {"_id":0,"InvoiceNo":1,"InvoiceDate":1,"CustomerName":1,"CustomerGST":1,"PlaceOfSupply":1,"Items":1,"BillingType":1,"CreatedBy":1,"SubTotal":1,"CGST":1,"SGST":1,"IGST":1,"TotalAmount":1})
                .sort([("InvoiceDate", DESCENDING), ("Id", DESCENDING)]))
    
    # Process rows to extract HSN and Quantity from sales_items collection
    processed_rows = []
    for r in rows:
        row_data = {
            "InvoiceNo": r.get("InvoiceNo", ""),
            "InvoiceDate": r.get("InvoiceDate", ""),
            "CustomerName": r.get("CustomerName", ""),
            "CustomerGST": r.get("CustomerGST", ""),
            "PlaceOfSupply": r.get("PlaceOfSupply", ""),
            "HSN": "",
            "Quantity": 0,
            "BillingType": r.get("BillingType", ""),
            "CreatedBy": r.get("CreatedBy", ""),
            "SubTotal": r.get("SubTotal", 0),
            "CGST": r.get("CGST", 0),
            "SGST": r.get("SGST", 0),
            "IGST": r.get("IGST", 0),
            "TotalAmount": r.get("TotalAmount", 0)
        }
        
        # Get first item from sales_items collection
        item = col("sales_items").find_one({"InvoiceId": r.get("Id")}, {"_id": 0, "HSN": 1, "Qty": 1})
        if item:
            row_data["HSN"] = item.get("HSN", "")
            row_data["Quantity"] = to_float(item.get("Qty", 0), 0)
        
        processed_rows.append(row_data)
    
    totals = {"SubTotal":0,"CGST":0,"SGST":0,"IGST":0,"TotalAmount":0}
    for r in processed_rows:
        for k in totals:
            totals[k] += to_float(r.get(k),0)
    return JSONResponse(content={"data": processed_rows, "count": len(processed_rows), "totals": totals})

# ─────────────────────────────────────────────
#  BILLING — BACKUP (stub — data is in MongoDB)
# ─────────────────────────────────────────────
@app.post("/api/billing/backup")
async def billing_backup():
    return ok({"success": True, "message": "Data is stored in MongoDB Atlas — no local backup needed. Use MongoDB Atlas backup features.", "recentBackups": []})

@app.get("/api/billing/backups")
async def billing_backups():
    return JSONResponse(content=[])

@app.post("/api/billing/reset-sequences")
async def billing_reset_sequences():
    return ok({"message": "Sequences are auto-calculated from existing records in MongoDB.", "invoiceCount": 0, "quotationCount": 0})

# ─────────────────────────────────────────────
#  REPORTS (non-billing)
# ─────────────────────────────────────────────
@app.get("/api/reports/sales")
async def reports_sales(
    fr: Optional[str] = Query(None, alias="from"), to: Optional[str] = Query(None),
    type: Optional[str] = Query(None)
):
    return await billing_reports_sales(fr=fr, to=to, type=type)

# ─────────────────────────────────────────────
#  CLIENT-SIDE LOGGING  →  uses main logger
# ─────────────────────────────────────────────
# Reuse the top-level logger (already configured above with file + stdout)
_log = logging.getLogger("rio_erp_api")
# LOG_FILE exposed for /api/log/tail endpoint
LOG_FILE = _LOG_FILE  # None on Render, Path on Windows

class LogEntry(BaseModel):
    level:   str = "INFO"
    user:    str = "unknown"
    action:  str = ""
    detail:  str = ""
    page:    str = ""
    ts:      str = ""

@app.get("/api/log/where")
async def log_where():
    """Shows where the log file is (or tells you it's on Render stdout)."""
    import platform as _p
    return {
        "platform": _p.system(),
        "log_file": str(LOG_FILE) if LOG_FILE else None,
        "log_exists": LOG_FILE.exists() if LOG_FILE else False,
        "note": (
            f"Log file at: {LOG_FILE}" if LOG_FILE and LOG_FILE.exists()
            else "Running on Render/Linux — logs go to Render dashboard Logs tab, not a file."
        )
    }

@app.get("/api/log/tail")
async def log_tail(n: int = 100):
    """Return last n lines of the log file (Windows only; Render uses stdout)."""
    if not LOG_FILE or not LOG_FILE.exists():
        return {"lines": [], "note": "Log file not available on this platform. On Render, check the Logs tab in the dashboard."}
    try:
        lines = LOG_FILE.read_text(encoding="utf-8").splitlines()
        return {"lines": lines[-n:], "total": len(lines), "file": str(LOG_FILE)}
    except Exception as e:
        return {"lines": [], "error": str(e)}


# ─────────────────────────────────────────────
#  ATTENDANCE — matches PS1 v2.1 structure
#  Collection: att_records, att_staff
# ─────────────────────────────────────────────
# get_attendance: replaced by full version from attendance_api below
# upsert_attendance: replaced by attendance_api version below
# ── Server-side admin check for sensitive routes ─────────────────────────────────────────────
# Hiding a button in the page is not protection: before this, anyone who could reach the server could
# create an admin user, reset any password, or download the database by calling the URL directly.
# The page already sends the login token as "Authorization: Bearer <token>"; these helpers verify it
# against the database. EMERGENCY SWITCH: set the environment variable RIO_ENFORCE_ADMIN=0 on Render
# to turn the check off if it ever locks the owner out.
API_LEVEL = 1          # bump only when the page starts depending on new server behaviour
API_BUILD = "v24"

def _enforce_admin() -> bool:
    return os.getenv("RIO_ENFORCE_ADMIN", "1").strip() != "0"

def _bearer_token(request: Request) -> str:
    h = (request.headers.get("authorization") or "").strip()
    return h[7:].strip() if h.lower().startswith("bearer ") else ""

async def admin_guard(request: Request):
    """None if the caller may proceed, otherwise the error response to return."""
    if not _enforce_admin(): return None
    if not await ensure_db(): return err("Database not connected", 503)
    tok = _bearer_token(request)
    if not tok:
        return err("Login required - no session token was sent. Please log out and log in again.", 401)
    me = _db["green_digital_users"].find_one({"session_token": tok}, {"_id": 0})
    if not me:
        return err("Your session has expired (it also ends when the same user logs in somewhere else). Please log out and log in again.", 401)
    if (me.get("role") or "").lower() != "admin":
        return err("Admin access is required for this action.", 403)
    return None

# ── Bank / cash accounts ───────────────────────────────────────────────────────────────────────
# Green Digital has no built-in bank accounts any more (they used to be Rio's: KVB MOM, KVB Mani, Indian Bank).
# The owner types up to three account names in Company Details > Bank Accounts; Cash is always available.
def get_account_names():
    """Account names set up in Company Details (blank ones skipped)."""
    try:
        d = col("company_details").find_one({}, {"_id": 0}) or {}
    except Exception:
        d = {}
    out = []
    for k in ("Acct1Name", "Acct2Name", "Acct3Name"):
        v = (d.get(k) or "").strip()
        if v and v not in out:
            out.append(v)
    return out

def ledger_account_for(mode):
    """The ledger account a payment mode posts to. Cash -> 'Cash Balance'; Pending / blank -> nothing;
    any other name posts under that same name, so a record saved under an account name that has since
    been renamed or removed keeps its ledger entry when it is edited."""
    m = (mode or "").strip()
    if not m or m == "Pending":
        return None
    return "Cash Balance" if m == "Cash" else m

@app.post("/api/auth/login")
async def login(request: Request):
    if not await ensure_db():
        return JSONResponse(content={"ok": False, "error": "Database not connected. Please try again in a moment."}, status_code=503)
    b = await request.json()
    username = (b.get("username") or "").strip().lower()
    password = (b.get("password") or "").strip()
    if not username or not password:
        return err("Username and password required", 400)
    user = _db["green_digital_users"].find_one({"username": username}, {"_id": 0})
    if not user:
        return err("Invalid username or password", 401)
    if not verify_password(password, user["password"]):
        return err("Invalid username or password", 401)
    # Accept any role — built-in or custom roles created in User Management
    role = user.get("role", "guest") or "guest"
    scope = user.get("scope", "all")
    # Generate a session token and store it so protected endpoints can verify
    token = secrets.token_hex(32)
    _db["green_digital_users"].update_one(
        {"username": username},
        {"$set": {"session_token": token}}
    )
    mobile_access = bool(user.get("mobile_access", False))
    # If login is from mobile app, block users without mobile_access
    source = (b.get("source") or "web").strip().lower()
    if source == "mobile" and not mobile_access and role != "admin":
        return err("Mobile access not enabled for this account. Please contact your administrator.", 403)
    return JSONResponse(content={
        "ok": True,
        "username": user["username"],
        "name": user.get("name", username),
        "role": role,
        "scope": scope,
        "token": token,
        "mobile_access": mobile_access
    })

@app.get("/api/billing/users")
@app.get("/api/auth/users")
async def get_users():
    if not await ensure_db():
        return JSONResponse(content={"error": "Database not connected"}, status_code=503)
    # Always read from master DB regardless of company context
    users = list(_db["green_digital_users"].find({}, {"_id": 0, "password": 0, "session_token": 0}))
    return JSONResponse(content=users)

@app.post("/api/auth/users")
async def create_user(request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    b = await request.json()
    username = (b.get("username") or "").strip().lower()
    password = (b.get("password") or "").strip()
    role     = (b.get("role") or "expense").strip()
    name     = (b.get("name") or username).strip()
    if not username or not password:
        return err("Username and password required")
    # Accept any role — including custom roles created in User Management
    if not role:
        role = "guest"
    if col("green_digital_users").find_one({"username": username}):
        return err("Username already exists")
    scope = (b.get("scope") or "all").strip()
    if scope not in {"all", "own"}: scope = "all"
    mobile_access_flag = bool(b.get("mobile_access", False))
    col("green_digital_users").insert_one({
        "username": username,
        "password": hash_password(password),
        "role": role,
        "name": name,
        "scope": scope,
        "mobile_access": mobile_access_flag
    })
    return ok({"ok": True})

@app.put("/api/auth/users/{username}")
async def update_user(username: str, request: Request):
    b = await request.json()
    if _enforce_admin():
        if not await ensure_db(): return err("Database not connected", 503)
        tok = _bearer_token(request)
        me = _db["green_digital_users"].find_one({"session_token": tok}, {"_id": 0}) if tok else None
        if not me:
            return err("Login required - please log out and log in again.", 401)
        if (me.get("role") or "").lower() != "admin":
            if (me.get("username") or "") != username.strip().lower():
                return err("Admin access is required for this action.", 403)
            # ordinary users may only change their own password (used by the first-login password change)
            b = {"password": b.get("password")} if b.get("password") else {}
    update = {}
    if b.get("password"): update["password"] = hash_password(b["password"])
    if b.get("role"):     update["role"]     = b["role"]
    if b.get("name"):     update["name"]     = b["name"]
    if b.get("scope") in {"all","own"}: update["scope"] = b["scope"]
    if "mobile_access" in b: update["mobile_access"] = bool(b["mobile_access"])
    if not update: return ok()
    col("green_digital_users").update_one({"username": username}, {"$set": update})
    return ok()

@app.delete("/api/auth/users/{username}")
async def delete_user(username: str, request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if username == "admin":
        return err("Cannot delete admin user")
    col("green_digital_users").delete_one({"username": username})
    return ok()


# ══════════════════════════════════════════════════════════════
# MOBILE — quotation toggle, split-up CRUD
# ══════════════════════════════════════════════════════════════

@app.patch("/api/quotations/{qid}/mobile-toggle")
async def mobile_toggle_quotation(qid: int):
    """Toggle mobile_visible flag on a quotation."""
    if not await ensure_db(): return err("Database not connected", 503)
    q = col("quotations").find_one({"Id": qid}, {"_id": 0, "mobile_visible": 1})
    if not q: return err("Quotation not found", 404)
    new_val = not bool(q.get("mobile_visible", False))
    col("quotations").update_one({"Id": qid}, {"$set": {"mobile_visible": new_val}})
    return JSONResponse(content={"ok": True, "mobile_visible": new_val})

@app.get("/api/mobile/splitups")
async def get_mobile_splitups(
    user: Optional[str] = Query(None),
    role: Optional[str] = Query(None),
    limit: int = Query(100)
):
    """List split-ups. Admin sees all; others see only their own."""
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if role != "admin" and user:
        query["createdBy"] = user
    rows = list(col("mobile_splitups").find(query, {"_id": 0})
                .sort("createdAt", DESCENDING).limit(limit))
    return JSONResponse(content={"data": rows, "total": len(rows)})

@app.post("/api/mobile/splitups")
async def post_mobile_splitup(request: Request):
    """Save a new split-up calculation."""
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    from datetime import datetime, timezone, timedelta
    now = datetime.now(timezone.utc)
    doc = {
        "size":        b.get("size", ""),
        "billingType": b.get("billingType", "GST"),
        "qty":         int(b.get("qty", 0)),
        "gstQty":      int(b.get("gstQty", 0)),
        "nonGstQty":   int(b.get("nonGstQty", 0)),
        "rate":        float(b.get("rate", 0)),
        "gstRate":     float(b.get("gstRate", 18)),
        "gstAmount":   float(b.get("gstAmount", 0)),
        "gstValue":    float(b.get("gstValue", 0)),
        "gstTotal":    float(b.get("gstTotal", 0)),
        "nonGstAmount":float(b.get("nonGstAmount", 0)),
        "nonGstTotal": float(b.get("nonGstTotal", 0)),
        "grandTotal":  float(b.get("grandTotal", 0)),
        "createdBy":   b.get("createdBy", ""),
        "customerName": b.get("customerName", ""),
    }
    # Belt-and-braces dedup: an identical calculation from the same user
    # within the last 15s is a double-fire (double tap / duplicate event),
    # not a new entry — return the already-saved record instead of inserting.
    cutoff = (now - timedelta(seconds=15)).isoformat()
    dup = col("mobile_splitups").find_one(
        {**doc, "createdAt": {"$gte": cutoff}}, {"Id": 1, "_id": 0}
    )
    if dup:
        return JSONResponse(content={"ok": True, "Id": dup.get("Id"), "deduped": True})
    last = col("mobile_splitups").find_one({}, {"Id": 1, "_id": 0}, sort=[("Id", DESCENDING)])
    new_id = (last["Id"] if last and "Id" in last else 0) + 1
    doc["Id"] = new_id
    doc["createdAt"] = now.isoformat()
    col("mobile_splitups").insert_one(doc)
    return JSONResponse(content={"ok": True, "Id": new_id})

@app.delete("/api/mobile/splitups/{split_id}")
async def delete_mobile_splitup(split_id: int):
    """Delete a split-up record."""
    if not await ensure_db(): return err("Database not connected", 503)
    r = col("mobile_splitups").delete_one({"Id": split_id})
    if r.deleted_count == 0: return err("Split-up not found", 404)
    return JSONResponse(content={"ok": True})


# ══════════════════════════════════════════════════════════════
# CUSTOM ROLES — stored in MongoDB so all machines share them
# ══════════════════════════════════════════════════════════════

@app.get("/api/sizes")
async def get_sizes(company: str = "rio"):
    """Return the sizes list for a company. Stored in MongoDB sizes_list collection
    (one document per company); falls back to a legacy shared doc, then to defaults."""
    if not await ensure_db(): return err("Database not connected", 503)
    company = (company or "rio").lower()
    stored = col("sizes_list").find_one({"company": company}, {"_id": 0})
    if stored and stored.get("sizes"):
        return JSONResponse(content={"sizes": stored["sizes"]})
    # Legacy shared doc (pre-company-scoping) — use once, then let POST re-save per company
    legacy = col("sizes_list").find_one({"type": "main"}, {"_id": 0})
    if legacy and legacy.get("sizes"):
        return JSONResponse(content={"sizes": legacy["sizes"]})
    # Return hardcoded defaults
    defaults = [
        "16x6 Inches","18x6 Inches","12x18 Inches","12x12 Inches",
        "16x16 Inches","24x18 Inches","24x12 Inches","24x24 Inches",
        "36x12 Inches","36x24 Inches","48x4 Inches","Others"
    ]
    return JSONResponse(content={"sizes": defaults})

@app.post("/api/sizes")
async def save_sizes(request: Request):
    """Persist the full sizes list for a company to MongoDB, so every device
    (desktop and mobile) reads the same list via GET /api/sizes?company=..."""
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    company = (b.get("company") or "rio").lower()
    sizes = b.get("sizes")
    if not isinstance(sizes, list):
        return err("sizes must be a list")
    col("sizes_list").update_one(
        {"company": company},
        {"$set": {"company": company, "sizes": sizes, "UpdatedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}},
        upsert=True
    )
    return JSONResponse(content={"success": True, "count": len(sizes)})

@app.post("/api/sizes/rename")
async def rename_size(request: Request):
    """Cascade a size rename across all sales records, invoice items, and quotation items."""
    b = await request.json()
    old_name = (b.get("oldName") or "").strip()
    new_name = (b.get("newName") or "").strip()
    if not old_name or not new_name or old_name == new_name:
        return err("oldName and newName required and must differ")
    results = {}
    # Sales records: Size1, Size2 and Size3 fields
    r1 = col("sales_records").update_many({"Size1": old_name}, {"$set": {"Size1": new_name}})
    r2 = col("sales_records").update_many({"Size2": old_name}, {"$set": {"Size2": new_name}})
    r2b = col("sales_records").update_many({"Size3": old_name}, {"$set": {"Size3": new_name}})
    results["sales"] = r1.modified_count + r2.modified_count + r2b.modified_count
    # Invoice line items: SizeNotes field
    r3 = col("sales_items").update_many({"SizeNotes": old_name}, {"$set": {"SizeNotes": new_name}})
    results["invoice_items"] = r3.modified_count
    # Quotation line items: SizeNotes field
    r4 = col("quotation_items").update_many({"SizeNotes": old_name}, {"$set": {"SizeNotes": new_name}})
    results["quotation_items"] = r4.modified_count
    logger.info(f"Size rename '{old_name}' → '{new_name}': {results}")
    return ok({"renamed": results})

@app.post("/api/billing/invoices/{inv_id}/sync-from-sales")
async def sync_invoice_from_sales(inv_id: int):
    """Fully sync an invoice from its linked sales record — rebuilds all items and recalculates totals."""
    if not await ensure_db(): return err("Database not connected", 503)
    inv = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0})
    if not inv: return err("Invoice not found", 404)
    if inv.get("Status") == "Cancelled": return err("This invoice is cancelled and cannot be updated.", 409)
    inv_no = inv.get("InvoiceNo", "")
    if not inv_no: return err("Invoice has no InvoiceNo", 400)

    # Find the linked sales record
    sale = col("sales_records").find_one({"InvoiceNo": inv_no}, {"_id": 0})
    if not sale: return err(f"No sales record linked to invoice {inv_no}", 404)

    # Determine billing type
    is_gst = sale.get("BillingType", "") == "With Bill"
    billing_type_str = "GST"  # default — overridden below with IGST if needed

    # Look up product for HSN and GSTRate
    prod_name = sale.get("ProductSize") or sale.get("Category") or ""
    hsn = ""; gst_rate = 18.0
    product = col("green_digital_products").find_one(
        {"$or": [{"Name": prod_name}, {"name": prod_name}]}, {"_id": 0}
    )
    if product:
        hsn      = product.get("HSN") or product.get("hsn") or ""
        gst_rate = to_float(product.get("GSTRate") or product.get("gstrate"), 18.0)

    # Build line items — same logic as generateInvoiceFromSales
    items = []
    sno = 1
    q1 = to_float(sale.get("Qty1"), 0); r1 = to_float(sale.get("Rate1"), 0)
    if q1 > 0 and r1 > 0:
        tax1 = round(q1 * r1, 2)
        items.append({"SNo": sno, "ProductName": prod_name, "HSN": hsn,
                      "Qty": q1, "Rate": r1, "TaxableValue": tax1,
                      "GSTRate": gst_rate, "Total": tax1, "SizeNotes": sale.get("Size1", "")})
        sno += 1
    q2 = to_float(sale.get("Qty2"), 0); r2 = to_float(sale.get("Rate2"), 0)
    if q2 > 0 and r2 > 0:
        tax2 = round(q2 * r2, 2)
        items.append({"SNo": sno, "ProductName": prod_name, "HSN": hsn,
                      "Qty": q2, "Rate": r2, "TaxableValue": tax2,
                      "GSTRate": gst_rate, "Total": tax2, "SizeNotes": sale.get("Size2", "")})
        sno += 1
    q3 = to_float(sale.get("Qty3"), 0); r3 = to_float(sale.get("Rate3"), 0)
    if q3 > 0 and r3 > 0:
        tax3 = round(q3 * r3, 2)
        items.append({"SNo": sno, "ProductName": prod_name, "HSN": hsn,
                      "Qty": q3, "Rate": r3, "TaxableValue": tax3,
                      "GSTRate": gst_rate, "Total": tax3, "SizeNotes": sale.get("Size3", "")})
        sno += 1

    # Packing & Forwarding line
    pf_amt   = to_float(sale.get("PFAmt"), 0)
    pf_gst   = to_float(sale.get("PFGst"), 0)
    pf_total = to_float(sale.get("PFTotal"), 0)
    if pf_amt > 0:
        pf_taxable = pf_amt
        items.append({"SNo": sno, "ProductName": "Packing and Forwarding", "HSN": "",
                      "Qty": 1, "Rate": pf_amt, "TaxableValue": pf_taxable,
                      "GSTRate": pf_gst, "Total": pf_total if pf_total > 0 else pf_taxable,
                      "SizeNotes": ""})
        sno += 1

    if not items:
        return err("Sales record has no line items (Qty/Rate missing)")

    # Look up customer state for IGST vs CGST/SGST
    cust_state = "Tamil Nadu"; cust_state_code = "33"; cust_id = inv.get("CustomerId", 0)
    cust_doc = shared_col("green_digital_clients").find_one({"ClientName": sale.get("Customer", "")}, {"_id": 0})
    if cust_doc:
        cust_state      = cust_doc.get("State")     or "Tamil Nadu"
        cust_state_code = cust_doc.get("StateCode") or "33"
        cust_id         = cust_doc.get("Id", cust_id)
    is_same_state = not cust_state or "tamil" in cust_state.lower()

    # Calculate totals per item GSTRate
    sub_total = round(sum(it["TaxableValue"] for it in items), 2)
    cgst = sgst = igst = 0.0
    if is_gst:
        for it in items:
            tax_amt = round(it["TaxableValue"] * it["GSTRate"] / 100, 2)
            if is_same_state:
                cgst += round(tax_amt / 2, 2); sgst += round(tax_amt / 2, 2)
            else:
                igst += tax_amt
        cgst = round(cgst, 2); sgst = round(sgst, 2); igst = round(igst, 2)
        billing_type_str = "GST" if is_same_state else "IGST"
    else:
        billing_type_str = "NON-GST"

    grand = round(sub_total + cgst + sgst + igst)

    # Rebuild sales_items
    col("sales_items").delete_many({"InvoiceId": inv_id})
    for it in items:
        col("sales_items").insert_one({
            "InvoiceId": inv_id,
            "SNo": it["SNo"], "ProductName": it["ProductName"], "HSN": it["HSN"],
            "Qty": it["Qty"], "Rate": it["Rate"], "TaxableValue": it["TaxableValue"],
            "GSTRate": it["GSTRate"], "Total": it["Total"], "SizeNotes": it["SizeNotes"]
        })

    # Update invoice header
    update = {
        "CustomerName":      sale.get("Customer", inv.get("CustomerName", "")),
        "CustomerId":        cust_id,
        "CustomerGST":       cust_doc.get("GSTNo", "") if cust_doc else inv.get("CustomerGST", ""),
        "BillingType":       billing_type_str,
        "PlaceOfSupply":     cust_state,
        "PlaceOfSupplyCode": cust_state_code,
        "SubTotal":          sub_total,
        "CGST":              cgst, "SGST": sgst, "IGST": igst,
        "TotalAmount":       grand,
        "PFDesc":            sale.get("PFDesc", ""),
        "PFAmt":             pf_amt, "PFGst": pf_gst, "PFTotal": pf_total,
        "PaymentTerms":      "NEFT" if is_gst else "Cash",
    }
    col("sales_invoices").update_one({"Id": inv_id}, {"$set": update})
    logger.info(f"Full sync: Invoice {inv_no} rebuilt from sales SNo={sale.get('SNo')} — {len(items)} items, Total={grand}")
    return ok({"synced": True, "invoiceNo": inv_no, "items": len(items), "total": grand,
               "billingType": billing_type_str, "CGST": cgst, "SGST": sgst, "IGST": igst})

@app.get("/api/roles")
async def get_roles():
    if not await ensure_db():
        return JSONResponse(content=[], status_code=503)
    roles = list(col("green_digital_custom_roles").find({}, {"_id": 0}))
    return JSONResponse(content=roles)

@app.post("/api/roles")
async def save_role(request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    role_id = (b.get("id") or "").strip()
    if not role_id: return err("role id required")
    col("green_digital_custom_roles").update_one(
        {"id": role_id},
        {"$set": b},
        upsert=True
    )
    return ok({"ok": True})

@app.delete("/api/roles/{role_id}")
async def delete_role(role_id: str, request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    col("green_digital_custom_roles").delete_one({"id": role_id})
    return ok()

# ══════════════════════════════════════════════════════════════
# ATTENDANCE TRACKER — routes on /api/attendance/*
# ══════════════════════════════════════════════════════════════


# ── Calculation helpers ───────────────────────────────────────────────────────

def norm_date(d: str) -> str:
    """Normalize to YYYY-MM-DD."""
    d = d.strip().replace("/", "-").replace("\\", "-")
    parts = d.split("-")
    if len(parts) != 3:
        return d
    if len(parts[0]) == 4:
        return f"{parts[0]}-{parts[1].zfill(2)}-{parts[2].zfill(2)}"
    return f"{parts[2]}-{parts[1].zfill(2)}-{parts[0].zfill(2)}"

# ── Ping ──────────────────────────────────────────────────────────────────────
# /api/attendance/ping is already defined above — skipping duplicate

# ── Employees list ────────────────────────────────────────────────────────────
# ── Get records ───────────────────────────────────────────────────────────────
# ── Upsert (add or update) ────────────────────────────────────────────────────
# ── Bulk upsert (CSV import) ──────────────────────────────────────────────────
# ── Recalculate all ───────────────────────────────────────────────────────────
# ── Delete records ────────────────────────────────────────────────────────────
# ── Delete ALL records (both collections) ────────────────────────────────────
# ── Delete single record by name+date ─────────────────────────────────────────

@app.get("/api/company")
async def get_company():
    # Uses col() which auto-routes to Rio or Rainbow DB
    record = col("company_details").find_one({}, {"_id": 0})
    return record or {}

@app.post("/api/company")
async def save_company(request: Request):
    data = await request.json()
    data.pop("_id", None)
    # Save only the specific section to avoid overwriting other sections
    section = data.pop("section", None)
    col("company_details").update_one({}, {"$set": data}, upsert=True)
    return {"success": True}



@app.post("/api/sales/migrate-customer-gst")
@app.post("/api/billing/sales/migrate-customer-gst")
async def migrate_customer_gst():
    """One-time migration: copy CustomerGST and StateCode from customers into sales records."""
    if not await ensure_db():
        return err("Database not connected", 503)
    try:
        # Build customer lookup map: Name → {GSTNo, StateCode}
        customers = list(col("customers").find({}, {"_id":0,"Name":1,"GSTNo":1,"StateCode":1}))
        cust_map = {c.get("Name","").strip().lower(): c for c in customers if c.get("Name")}

        # Find all sales records that don't have CustomerGST yet
        sales = list(col("sales_records").find(
            {"$or": [{"CustomerGST": {"$exists": False}}, {"CustomerGST": ""}]},
            {"_id":1, "Customer":1}
        ))
        updated = 0
        for s in sales:
            name = (s.get("Customer") or "").strip().lower()
            c = cust_map.get(name)
            if c and (c.get("GSTNo") or c.get("StateCode")):
                col("sales_records").update_one(
                    {"_id": s["_id"]},
                    {"$set": {
                        "CustomerGST": c.get("GSTNo", ""),
                        "CustomerStateCode": c.get("StateCode", "")
                    }}
                )
                updated += 1
        return {"success": True, "updated": updated, "total": len(sales)}
    except Exception as e:
        return err(str(e), 500)


@app.post("/api/customers/merge-shared")
@app.post("/api/billing/customers/merge-shared")
async def merge_customers_to_shared():
    """One-time migration: copy Rainbow customers into RioPrintMedia.rio_clients."""
    if not await ensure_db(): return err("Database not connected", 503)
    try:
        if not _client: return err("No DB client")
        rainbow_clients = list(_client[MONGO_DB_RAINBOW]["green_digital_clients"].find({}, {"_id": 0}))
        merged = 0
        skipped = 0
        for c in rainbow_clients:
            name = (c.get("ClientName") or c.get("Name") or "").strip()
            if not name:
                continue
            exists = shared_col("green_digital_clients").find_one({"ClientName": {"$regex": f"^{re.escape(name)}$", "$options": "i"}})
            if exists:
                skipped += 1
                continue
            # Assign new Id
            new_id = next_id("green_digital_clients")
            c["Id"] = new_id
            c.pop("_id", None)
            shared_col("green_digital_clients").insert_one(c)
            merged += 1
        return ok({"success": True, "merged": merged, "skipped": skipped, "total": len(rainbow_clients)})
    except Exception as e:
        return err(str(e), 500)


@app.put("/api/categories")
@app.put("/api/billing/categories")
async def put_category(request: Request):
    """Rename a category or subcategory."""
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    old_cat = (b.get("oldCategory") or "").strip()
    new_cat = (b.get("newCategory") or "").strip()
    old_sub = (b.get("oldSubCategory") or "").strip()
    new_sub = (b.get("newSubCategory") or "").strip()
    try:
        if old_sub and new_sub:
            # Rename subcategory
            col("expense_categories").update_many(
                {"CategoryName": old_cat, "SubCategoryName": old_sub},
                {"$set": {"SubCategoryName": new_sub}}
            )
            # Update existing expense records
            col("daily_expenses").update_many(
                {"Category": old_cat, "SubCategory": old_sub},
                {"$set": {"SubCategory": new_sub}}
            )
        elif old_cat and new_cat:
            # Rename category
            col("expense_categories").update_many(
                {"CategoryName": old_cat},
                {"$set": {"CategoryName": new_cat}}
            )
            # Update existing expense records
            col("daily_expenses").update_many(
                {"Category": old_cat},
                {"$set": {"Category": new_cat}}
            )
        return ok({"success": True})
    except Exception as e:
        return err(str(e), 500)

@app.post("/api/categories/add")
@app.post("/api/billing/categories/add")
async def add_category(request: Request):
    """Add a new category (no subcategory required)."""
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    cat = (b.get("CategoryName") or "").strip()
    sub = (b.get("SubCategoryName") or "").strip()
    if not cat: return err("Category name required")
    try:
        if sub:
            exists = col("expense_categories").find_one({"CategoryName": cat, "SubCategoryName": sub})
            if not exists:
                new_id = next_id("expense_categories")
                col("expense_categories").insert_one({"Id": new_id, "CategoryName": cat, "SubCategoryName": sub})
        else:
            # Add category with empty placeholder sub if it doesn't exist at all
            exists = col("expense_categories").find_one({"CategoryName": cat})
            if not exists:
                new_id = next_id("expense_categories")
                col("expense_categories").insert_one({"Id": new_id, "CategoryName": cat, "SubCategoryName": ""})
        return ok({"success": True})
    except Exception as e:
        return err(str(e), 500)


@app.post("/api/billing/sales/migrate-gst-rates")
@app.post("/api/sales/migrate-gst-rates")
async def migrate_gst_rates():
    """Patch GSTRate1 on old sales records from products collection."""
    if not await ensure_db(): return err("Database not connected", 503)
    try:
        sales = list(col("sales").find({"$or": [{"GSTRate1": {"$exists": False}}, {"GSTRate1": 0}]}))
        products = {p.get("ProductCode") or p.get("Id"): p for p in col("products").find({})}
        updated = 0
        for s in sales:
            pid = s.get("ProductId")
            if pid and str(pid) in products:
                gst = products[str(pid)].get("GSTRate") or products[str(pid)].get("gstRate") or 0
                if gst:
                    col("sales").update_one({"_id": s["_id"]}, {"$set": {"GSTRate1": float(gst)}})
                    updated += 1
        return ok({"success": True, "updated": updated})
    except Exception as e:
        return err(str(e), 500)


# ══════════════════════════════════════════════════════════════
# END ATTENDANCE
# ══════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════
# PURCHASE AND STOCK MODULE
# ══════════════════════════════════════════════════════════════
# Collections (company-separated via existing middleware):
#   suppliers        — supplier master
#   purchases        — purchase headers (P001, P002…)
#   purchase_items   — line items per purchase
#   stock_ledger     — every IN/OUT movement with running balance

# ── SUPPLIERS ─────────────────────────────────────────────────

@app.get("/api/billing/suppliers")
async def get_suppliers(q: Optional[str] = Query(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if q:
        query = {"$or": [
            {"Name":    {"$regex": q, "$options": "i"}},
            {"GSTNo":   {"$regex": q, "$options": "i"}},
            {"Phone":   {"$regex": q, "$options": "i"}},
        ]}
    docs = list(col("suppliers").find(query, {"_id": 0}).sort("Name", 1))
    return JSONResponse(content={"data": docs, "total": len(docs)})

@app.get("/api/billing/suppliers/{sup_id}")
async def get_supplier(sup_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    doc = col("suppliers").find_one({"Id": sup_id}, {"_id": 0})
    if not doc: return err("Supplier not found", 404)
    return JSONResponse(content=doc)

@app.post("/api/billing/suppliers")
async def create_supplier(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    if not data.get("Name"): return err("Name is required")
    new_id = next_id("suppliers")
    doc = {
        "Id":            new_id,
        "Name":          data.get("Name", "").strip(),
        "ContactPerson": data.get("ContactPerson", "").strip(),
        "Phone":         data.get("Phone", "").strip(),
        "Email":         data.get("Email", "").strip(),
        "GSTNo":         data.get("GSTNo", "").strip(),
        "BillToAddress": data.get("BillToAddress", "").strip(),
        "BankDetails":   data.get("BankDetails", "").strip(),
        "CreatedAt":     datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    col("suppliers").insert_one(doc)
    return ok({"Id": new_id, "Name": doc["Name"]})

@app.put("/api/billing/suppliers/{sup_id}")
async def update_supplier(sup_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    if not data.get("Name"): return err("Name is required")
    update = {
        "Name":          data.get("Name", "").strip(),
        "ContactPerson": data.get("ContactPerson", "").strip(),
        "Phone":         data.get("Phone", "").strip(),
        "Email":         data.get("Email", "").strip(),
        "GSTNo":         data.get("GSTNo", "").strip(),
        "BillToAddress": data.get("BillToAddress", "").strip(),
        "BankDetails":   data.get("BankDetails", "").strip(),
    }
    result = col("suppliers").update_one({"Id": sup_id}, {"$set": update})
    if result.matched_count == 0: return err("Supplier not found", 404)
    return ok({"updated": True})

@app.delete("/api/billing/suppliers/{sup_id}")
async def delete_supplier(sup_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    # Block deletion if there are purchases referencing this supplier
    if col("purchases").find_one({"SupplierId": sup_id}):
        return err("Cannot delete — supplier has purchase records", 400)
    result = col("suppliers").delete_one({"Id": sup_id})
    if result.deleted_count == 0: return err("Supplier not found", 404)
    return ok({"deleted": True})

# ── PURCHASES ─────────────────────────────────────────────────

@app.get("/api/billing/purchases/next-no")
async def get_next_purchase_no():
    if not await ensure_db(): return err("Database not connected", 503)
    last = col("purchases").find_one({}, sort=[("Id", -1)])
    next_num = (last["Id"] + 1) if last else 1
    return ok({"PurchaseNo": f"P{next_num:03d}", "next": next_num})

@app.get("/api/billing/purchases")
async def get_purchases(q: Optional[str] = Query(None),
                        supplier_id: Optional[int] = Query(None),
                        page: int = Query(1), page_size: int = Query(50)):
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if q:
        query["$or"] = [
            {"PurchaseNo":    {"$regex": q, "$options": "i"}},
            {"SupplierName":  {"$regex": q, "$options": "i"}},
        ]
    if supplier_id:
        query["SupplierId"] = supplier_id
    total = col("purchases").count_documents(query)
    skip  = (page - 1) * page_size
    docs  = list(col("purchases").find(query, {"_id": 0})
                 .sort("Id", -1).skip(skip).limit(page_size))
    return JSONResponse(content={"data": docs, "total": total, "page": page, "pageSize": page_size})

@app.get("/api/billing/purchases/{purchase_id}")
async def get_purchase(purchase_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    doc = col("purchases").find_one({"Id": purchase_id}, {"_id": 0})
    if not doc: return err("Purchase not found", 404)
    items = list(col("purchase_items").find(
        {"PurchaseId": purchase_id}, {"_id": 0}).sort("SNo", 1))
    return JSONResponse(content={**doc, "Items": items})

@app.post("/api/billing/purchases")
async def create_purchase(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    if not data.get("SupplierId"): return err("SupplierId is required")
    items = data.get("Items", [])
    if not items: return err("At least one item is required")

    purchase_id   = next_id("purchases")
    purchase_no   = f"P{purchase_id:03d}"
    purchase_date = data.get("PurchaseDate", datetime.now().strftime("%Y-%m-%d"))
    supplier      = col("suppliers").find_one({"Id": int(data["SupplierId"])}, {"_id": 0})
    supplier_name = supplier["Name"] if supplier else data.get("SupplierName", "")

    sub_total = 0.0
    processed = []
    for i, it in enumerate(items):
        qty    = float(it.get("Qty", 0))
        rate   = float(it.get("Rate", 0))
        total  = qty * rate
        sub_total += total
        processed.append({
            "PurchaseId":  purchase_id,
            "SNo":         i + 1,
            "ProductName": it.get("ProductName", "").strip(),
            "HSN":         it.get("HSN", "").strip(),
            "Qty":         qty,
            "Unit":        it.get("Unit", "Nos").strip(),
            "Rate":        rate,
            "Total":       round(total, 2),
        })

    doc = {
        "Id":           purchase_id,
        "PurchaseNo":   purchase_no,
        "PurchaseDate": purchase_date,
        "SupplierId":   int(data["SupplierId"]),
        "SupplierName": supplier_name,
        "InvoiceRef":   data.get("InvoiceRef", "").strip(),
        "SubTotal":     round(sub_total, 2),
        "TotalAmount":  round(sub_total, 2),
        "Notes":        data.get("Notes", "").strip(),
        "CreatedAt":    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    col("purchases").insert_one(doc)
    if processed:
        col("purchase_items").insert_many(processed)

    # Automatically write Stock IN entries for each item
    for it in processed:
        if it["ProductName"] and it["Qty"] > 0:
            stock_id = next_id("stock_ledger")
            col("stock_ledger").insert_one({
                "Id":          stock_id,
                "Date":        purchase_date,
                "ProductName": it["ProductName"],
                "Type":        "IN",
                "Qty":         it["Qty"],
                "Unit":        it["Unit"],
                "Rate":        it["Rate"],
                "Reference":   purchase_no,
                "Remarks":     f"Purchase from {supplier_name}",
                "CreatedAt":   datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })

    return ok({"Id": purchase_id, "PurchaseNo": purchase_no})

@app.put("/api/billing/purchases/{purchase_id}")
async def update_purchase(purchase_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    purchase = col("purchases").find_one({"Id": purchase_id})
    if not purchase: return err("Purchase not found", 404)
    data = await request.json()
    if not data.get("SupplierId"): return err("SupplierId is required")
    items = data.get("Items", [])
    if not items: return err("At least one item is required")

    old_no        = purchase["PurchaseNo"]
    purchase_date = data.get("PurchaseDate", purchase.get("PurchaseDate"))
    supplier      = col("suppliers").find_one({"Id": int(data["SupplierId"])}, {"_id": 0})
    supplier_name = supplier["Name"] if supplier else data.get("SupplierName", "")

    sub_total = 0.0
    processed = []
    for i, it in enumerate(items):
        qty    = float(it.get("Qty", 0))
        rate   = float(it.get("Rate", 0))
        total  = qty * rate
        sub_total += total
        processed.append({
            "PurchaseId":  purchase_id,
            "SNo":         i + 1,
            "ProductName": it.get("ProductName", "").strip(),
            "HSN":         it.get("HSN", "").strip(),
            "Qty":         qty,
            "Unit":        it.get("Unit", "Nos").strip(),
            "Rate":        rate,
            "Total":       round(total, 2),
        })

    col("purchases").update_one({"Id": purchase_id}, {"$set": {
        "PurchaseDate": purchase_date,
        "SupplierId":   int(data["SupplierId"]),
        "SupplierName": supplier_name,
        "InvoiceRef":   data.get("InvoiceRef", "").strip(),
        "SubTotal":     round(sub_total, 2),
        "TotalAmount":  round(sub_total, 2),
        "Notes":        data.get("Notes", "").strip(),
    }})

    # Replace purchase_items
    col("purchase_items").delete_many({"PurchaseId": purchase_id})
    if processed:
        col("purchase_items").insert_many(processed)

    # Replace the auto-generated Stock IN entries for this purchase
    col("stock_ledger").delete_many({"Reference": old_no, "Type": "IN"})
    for it in processed:
        if it["ProductName"] and it["Qty"] > 0:
            stock_id = next_id("stock_ledger")
            col("stock_ledger").insert_one({
                "Id":          stock_id,
                "Date":        purchase_date,
                "ProductName": it["ProductName"],
                "Type":        "IN",
                "Qty":         it["Qty"],
                "Unit":        it["Unit"],
                "Rate":        it["Rate"],
                "Reference":   old_no,
                "Remarks":     f"Purchase from {supplier_name}",
                "CreatedAt":   datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })

    return ok({"Id": purchase_id, "PurchaseNo": old_no})

@app.delete("/api/billing/purchases/{purchase_id}")
async def delete_purchase(purchase_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    purchase = col("purchases").find_one({"Id": purchase_id})
    if not purchase: return err("Purchase not found", 404)
    # Remove the auto-generated stock IN entries for this purchase
    col("stock_ledger").delete_many({"Reference": purchase["PurchaseNo"], "Type": "IN"})
    col("purchase_items").delete_many({"PurchaseId": purchase_id})
    col("purchases").delete_one({"Id": purchase_id})
    return ok({"deleted": True})

# ── STOCK LEDGER ──────────────────────────────────────────────

@app.get("/api/billing/stock/ledger")
async def get_stock_ledger(product: Optional[str] = Query(None),
                           type_filter: Optional[str] = Query(None),
                           date_from: Optional[str] = Query(None),
                           date_to: Optional[str] = Query(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if product:
        query["ProductName"] = {"$regex": product, "$options": "i"}
    if type_filter in ("IN", "OUT"):
        query["Type"] = type_filter
    if date_from or date_to:
        query["Date"] = {}
        if date_from: query["Date"]["$gte"] = date_from
        if date_to:   query["Date"]["$lte"] = date_to
    docs = list(col("stock_ledger").find(query, {"_id": 0}).sort([("Date", 1), ("Id", 1)]))
    # Compute running balance per product
    balances = {}
    for d in docs:
        p = d["ProductName"]
        balances.setdefault(p, 0)
        qty = float(d.get("Qty", 0))
        if d["Type"] == "IN":  balances[p] += qty
        else:                  balances[p] -= qty
        d["Balance"] = round(balances[p], 2)
    docs.reverse()   # most recent first for display
    return JSONResponse(content={"data": docs, "total": len(docs)})

@app.get("/api/billing/stock/products")
async def get_stock_products():
    """Distinct product names that appear in the ledger — for dropdowns."""
    if not await ensure_db(): return err("Database not connected", 503)
    names = col("stock_ledger").distinct("ProductName")
    names.sort()
    return JSONResponse(content={"data": names})

@app.get("/api/billing/stock/summary")
async def get_stock_summary():
    """Current balance per product — for dashboard widget."""
    if not await ensure_db(): return err("Database not connected", 503)
    pipeline = [
        {"$group": {
            "_id": "$ProductName",
            "in_qty":  {"$sum": {"$cond": [{"$eq": ["$Type","IN"]},  {"$toDouble": "$Qty"}, 0]}},
            "out_qty": {"$sum": {"$cond": [{"$eq": ["$Type","OUT"]}, {"$toDouble": "$Qty"}, 0]}},
        }},
        {"$project": {
            "ProductName": "$_id",
            "Balance": {"$subtract": ["$in_qty", "$out_qty"]},
            "InTotal": "$in_qty", "OutTotal": "$out_qty",
        }},
        {"$sort": {"ProductName": 1}}
    ]
    docs = list(col("stock_ledger").aggregate(pipeline))
    for d in docs: d.pop("_id", None)
    return JSONResponse(content={"data": docs})

@app.post("/api/billing/stock/out")
async def add_stock_out(request: Request):
    """Manual OUT entry — posted by office after raising an invoice."""
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    product = data.get("ProductName", "").strip()
    qty     = float(data.get("Qty", 0))
    if not product: return err("ProductName is required")
    if qty <= 0:    return err("Qty must be positive")
    stock_id = next_id("stock_ledger")
    col("stock_ledger").insert_one({
        "Id":          stock_id,
        "Date":        data.get("Date", datetime.now().strftime("%Y-%m-%d")),
        "ProductName": product,
        "Type":        "OUT",
        "Qty":         qty,
        "Unit":        data.get("Unit", "Nos").strip(),
        "Rate":        float(data.get("Rate", 0)),
        "CustomerName": data.get("CustomerName", "").strip(),
        "JobName":     data.get("JobName", "").strip(),
        "JobSize":     data.get("JobSize", "").strip(),
        "JobQty":      data.get("JobQty", "").strip(),
        "UpdatedBy":   data.get("UpdatedBy", "").strip(),
        "Reference":   data.get("Reference", "").strip(),
        "Remarks":     data.get("Remarks", "").strip(),
        "CreatedAt":   datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })
    return ok({"Id": stock_id})

@app.put("/api/billing/stock/ledger/{entry_id}")
async def update_stock_entry(entry_id: int, request: Request):
    """Edit a manual OUT entry only (auto IN entries are only changed via the Purchase)."""
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    entry = col("stock_ledger").find_one({"Id": entry_id})
    if not entry: return err("Entry not found", 404)
    if entry.get("Type") == "IN":
        return err("Cannot edit an auto IN entry — edit the Purchase instead", 400)
    product = data.get("ProductName", "").strip()
    qty     = float(data.get("Qty", 0))
    if not product: return err("ProductName is required")
    if qty <= 0:    return err("Qty must be positive")
    col("stock_ledger").update_one({"Id": entry_id}, {"$set": {
        "Date":        data.get("Date", entry.get("Date")),
        "ProductName": product,
        "Qty":         qty,
        "Unit":        data.get("Unit", "Nos").strip(),
        "Rate":        float(data.get("Rate", 0)),
        "CustomerName": data.get("CustomerName", "").strip(),
        "JobName":     data.get("JobName", "").strip(),
        "JobSize":     data.get("JobSize", "").strip(),
        "JobQty":      data.get("JobQty", "").strip(),
        "UpdatedBy":   data.get("UpdatedBy", "").strip(),
        "Reference":   data.get("Reference", "").strip(),
        "Remarks":     data.get("Remarks", "").strip(),
    }})
    return ok({"updated": True})

@app.delete("/api/billing/stock/ledger/{entry_id}")
async def delete_stock_entry(entry_id: int):
    """Delete a manual OUT entry only (auto IN entries deleted via purchase delete)."""
    if not await ensure_db(): return err("Database not connected", 503)
    entry = col("stock_ledger").find_one({"Id": entry_id})
    if not entry: return err("Entry not found", 404)
    if entry.get("Type") == "IN":
        return err("Cannot delete an auto IN entry — delete the Purchase instead", 400)
    col("stock_ledger").delete_one({"Id": entry_id})
    return ok({"deleted": True})

# ── PURCHASE PRODUCTS CATALOG (Name + HSN, used by Purchases and Stock OUT) ──

@app.get("/api/billing/purchase-products")
async def get_purchase_products():
    if not await ensure_db(): return err("Database not connected", 503)
    docs = list(col("purchase_products").find({}, {"_id": 0}).sort("Name", 1))
    return JSONResponse(content={"data": docs})

@app.post("/api/billing/purchase-products")
async def add_purchase_product(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    name = data.get("Name", "").strip()
    if not name: return err("Product name is required")
    prod_id = next_id("purchase_products")
    col("purchase_products").insert_one({
        "Id": prod_id, "Name": name, "Size": data.get("Size", "").strip(), "HSN": data.get("HSN", "").strip(),
        "CreatedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })
    return ok({"Id": prod_id})

@app.put("/api/billing/purchase-products/{prod_id}")
async def update_purchase_product(prod_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    name = data.get("Name", "").strip()
    if not name: return err("Product name is required")
    r = col("purchase_products").update_one({"Id": prod_id}, {"$set": {
        "Name": name, "Size": data.get("Size", "").strip(), "HSN": data.get("HSN", "").strip(),
    }})
    if r.matched_count == 0: return err("Product not found", 404)
    return ok({"updated": True})

@app.delete("/api/billing/purchase-products/{prod_id}")
async def delete_purchase_product(prod_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("purchase_products").delete_one({"Id": prod_id})
    return ok({"deleted": True})

# ── EMPLOYEES (used by "Updated By" on Stock OUT entries) ────────────

@app.get("/api/billing/employees")
async def get_employees():
    if not await ensure_db(): return err("Database not connected", 503)
    docs = list(col("employees").find({}, {"_id": 0}).sort("Name", 1))
    return JSONResponse(content={"data": docs})

@app.post("/api/billing/employees")
async def add_employee(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    name = data.get("Name", "").strip()
    if not name: return err("Employee name is required")
    emp_id = next_id("employees")
    col("employees").insert_one({
        "Id": emp_id, "Name": name,
        "CreatedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })
    return ok({"Id": emp_id})

@app.put("/api/billing/employees/{emp_id}")
async def update_employee(emp_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    name = data.get("Name", "").strip()
    if not name: return err("Employee name is required")
    r = col("employees").update_one({"Id": emp_id}, {"$set": {"Name": name}})
    if r.matched_count == 0: return err("Employee not found", 404)
    return ok({"updated": True})

@app.delete("/api/billing/employees/{emp_id}")
async def delete_employee(emp_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("employees").delete_one({"Id": emp_id})
    return ok({"deleted": True})

# ── STOCK MOBILE PIN GATE + ACCESS LOG ────────────────────────
# Shared across both companies (one link, one team) — not company-scoped.

def _client_ip(request: Request) -> str:
    xff = request.headers.get("x-forwarded-for")
    if xff:
        return xff.split(",")[0].strip()
    return request.client.host if request.client else "unknown"

DEFAULT_STOCK_PIN = "1234"  # change this on first use via the Access Log screen in Purchase & Stock
DEFAULT_STOCK_PIN_SESSION_DAYS = 7

@app.get("/api/billing/stock-pin/config")
async def get_stock_pin_config():
    """Returns whether a PIN is set and how many days a device stays remembered.
    Never returns the PIN itself."""
    if not await ensure_db(): return err("Database not connected", 503)
    cfg = shared_col("stock_pin_config").find_one({"_key": "main"}, {"_id": 0})
    return JSONResponse(content={
        "sessionDays": (cfg or {}).get("SessionDays", DEFAULT_STOCK_PIN_SESSION_DAYS),
        "configured": bool(cfg and cfg.get("Pin")),
    })

@app.post("/api/billing/stock-pin/set")
async def set_stock_pin(request: Request):
    """Admin-only in practice (gated on the frontend, like other admin actions in this app)."""
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    pin = str(data.get("Pin", "")).strip()
    if not re.fullmatch(r"\d{4}", pin):
        return err("PIN must be exactly 4 digits")
    session_days = int(data.get("SessionDays", DEFAULT_STOCK_PIN_SESSION_DAYS) or DEFAULT_STOCK_PIN_SESSION_DAYS)
    shared_col("stock_pin_config").update_one(
        {"_key": "main"},
        {"$set": {"_key": "main", "Pin": pin, "SessionDays": session_days,
                   "UpdatedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}},
        upsert=True
    )
    return ok({"updated": True})

@app.post("/api/billing/stock-pin/verify")
async def verify_stock_pin(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    pin = str(data.get("Pin", "")).strip()
    device = str(data.get("Device", "")).strip()[:200]
    cfg = shared_col("stock_pin_config").find_one({"_key": "main"}, {"_id": 0})
    correct_pin = (cfg or {}).get("Pin", DEFAULT_STOCK_PIN)
    success = (pin == correct_pin)
    log_id = next_id("stock_access_log")
    shared_col("stock_access_log").insert_one({
        "Id": log_id,
        "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "IP": _client_ip(request),
        "Device": device or request.headers.get("user-agent", "unknown")[:200],
        "Success": success,
    })
    if not success:
        return err("Incorrect PIN", 401)
    return ok({"verified": True, "sessionDays": (cfg or {}).get("SessionDays", DEFAULT_STOCK_PIN_SESSION_DAYS)})

@app.get("/api/billing/stock-access-log")
async def get_stock_access_log(limit: int = Query(100, ge=1, le=500)):
    if not await ensure_db(): return err("Database not connected", 503)
    docs = list(shared_col("stock_access_log").find({}, {"_id": 0}).sort("Id", -1).limit(limit))
    return JSONResponse(content={"data": docs})

# ══════════════════════════════════════════════════════════════
# END PURCHASE AND STOCK
# ══════════════════════════════════════════════════════════════

# ── Database backup / restore (admin only) ─────────────────────────────────────────────
@app.get("/api/admin/backup")
async def admin_backup_database(request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    if not _client: return err("No DB client")
    from bson import json_util
    result = {}
    warnings = []
    for db_name in [MONGO_DB]:   # this app's own database only - never another business's data on the same cluster
        try:
            db = _client[db_name]
            db_dump = {}
            for coll_name in db.list_collection_names():
                try:
                    db_dump[coll_name] = list(db[coll_name].find({}, {"_id": 0}))
                except Exception as e:
                    warnings.append(f"{db_name}.{coll_name}: {e}")
            result[db_name] = db_dump
        except Exception as e:
            # One database being unreachable (permissions, doesn't exist on this
            # cluster tier, etc.) shouldn't sink the whole backup - record it and
            # keep going so the other database still gets backed up.
            warnings.append(f"{db_name}: {e}")
    payload = {
        "takenAt": datetime.utcnow().isoformat(),
        "databases": result,
        "warnings": warnings,
    }
    try:
        # json_util.dumps (not plain json.dumps/JSONResponse) is what actually
        # handles datetime, ObjectId, Decimal128 and other BSON types that real
        # Mongo documents commonly contain - a plain JSONResponse throws on the
        # first such field it hits anywhere in any collection, which is almost
        # certainly what the HTTP 500 was.
        body = json_util.dumps(payload)
        return Response(content=body, media_type="application/json")
    except Exception as e:
        return err(f"Backup built but could not be serialized: {e}", 500)

@app.post("/api/admin/restore")
async def admin_restore_database(request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    if not _client: return err("No DB client")
    from bson import json_util
    try:
        raw = await request.body()
        body = json_util.loads(raw)
    except Exception as e:
        return err(f"Could not parse backup file: {e}")
    databases = body.get("databases")
    if not isinstance(databases, dict) or not databases:
        return err("Backup file has no 'databases' section - is this a valid backup file?")
    try:
        summary = {}
        # Safety: only ever write into THIS app's database, whatever the file says. Without this a wrong or
        # tampered file could overwrite another application's database on the same cluster.
        foreign = [n for n in databases if n != MONGO_DB]
        if foreign:
            return err(f"This backup is for database {', '.join(foreign)} but this server uses {MONGO_DB}. Restore was refused.", 400)
        for db_name, collections in databases.items():
            if not isinstance(collections, dict): continue
            db = _client[db_name]
            db_summary = {}
            for coll_name, docs in collections.items():
                if not isinstance(docs, list): continue
                db[coll_name].delete_many({})
                if docs:
                    db[coll_name].insert_many([{k: v for k, v in d.items() if k != "_id"} for d in docs], ordered=False)
                db_summary[coll_name] = len(docs)
            summary[db_name] = db_summary
        return ok({"success": True, "restored": summary})
    except Exception as e:
        return err(str(e), 500)
